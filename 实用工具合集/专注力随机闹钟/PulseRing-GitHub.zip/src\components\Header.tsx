import clsx from 'clsx'
import { Eye, EyeOff, ShieldCheck } from 'lucide-react'
import type { BellEngine, Status } from '../hooks/useBellEngine'
import { Switch } from './primitives'

const STATUS_META: Record<Status, { label: string; dot: string; text: string; chip: string }> = {
  idle: {
    label: '待机中',
    dot: 'bg-slate-400',
    text: 'text-slate-300',
    chip: 'border-white/10 bg-white/[.04]',
  },
  waiting: {
    label: '等待随机时刻',
    dot: 'bg-cyan-300',
    text: 'text-cyan-200',
    chip: 'border-cyan-300/25 bg-cyan-300/[.07]',
  },
  ringing: {
    label: '正在响铃',
    dot: 'bg-amber-300',
    text: 'text-amber-200',
    chip: 'border-amber-300/30 bg-amber-300/[.08]',
  },
  paused: {
    label: '已暂停',
    dot: 'bg-violet-300',
    text: 'text-violet-200',
    chip: 'border-violet-300/25 bg-violet-300/[.07]',
  },
}

export function Header({ engine }: { engine: BellEngine }) {
  const { status, settings, update } = engine
  const meta = STATUS_META[status]

  return (
    <header className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
      <div className="flex items-center gap-3.5">
        <div className="relative grid h-12 w-12 place-items-center rounded-2xl border border-white/10 bg-gradient-to-br from-cyan-300/20 via-white/[.03] to-indigo-400/20 shadow-[inset_0_1px_0_rgba(255,255,255,.14),0_18px_40px_-18px_rgba(56,189,248,.55)]">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" aria-hidden>
            <circle cx="12" cy="12" r="8" stroke="url(#logoGrad)" strokeWidth="1.7" opacity=".95" />
            <circle cx="12" cy="12" r="3.1" fill="url(#logoGrad)" />
            <path
              d="M12 3.2v1.6M12 19.2v1.6M3.2 12h1.6M19.2 12h1.6"
              stroke="url(#logoGrad)"
              strokeWidth="1.5"
              strokeLinecap="round"
              opacity=".55"
            />
            <defs>
              <linearGradient id="logoGrad" x1="4" y1="4" x2="20" y2="20">
                <stop stopColor="#67e8f9" />
                <stop offset="1" stopColor="#818cf8" />
              </linearGradient>
            </defs>
          </svg>
          <span className="absolute -right-1 -top-1 flex h-3 w-3">
            <span
              className={clsx(
                'absolute inline-flex h-full w-full rounded-full opacity-60',
                status === 'idle' || status === 'paused' ? 'bg-slate-400' : 'animate-ping-soft bg-cyan-300',
              )}
            />
            <span
              className={clsx(
                'relative inline-flex h-3 w-3 rounded-full border-2 border-[#05070c]',
                meta.dot,
              )}
            />
          </span>
        </div>

        <div>
          <div className="flex items-center gap-2">
            <h1 className="bg-gradient-to-r from-white via-slate-100 to-slate-400 bg-clip-text text-[19px] font-semibold tracking-tight text-transparent">
              PulseRing
            </h1>
            <span className="rounded-md border border-white/[.08] bg-white/[.04] px-1.5 py-0.5 text-[9px] font-semibold tracking-[0.16em] text-slate-500">
              v2.0
            </span>
          </div>
          <p className="mt-0.5 text-[11px] tracking-wide text-slate-500">随机响铃 · 专注节律</p>
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-2.5">
        <span className="hidden items-center gap-1.5 rounded-full border border-white/[.06] bg-white/[.025] px-3 py-1.5 text-[10px] text-slate-500 md:inline-flex">
          <ShieldCheck size={12} className="text-emerald-300/80" />
          纯本地运行 · 无需联网
        </span>

        <div
          className={clsx(
            'inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-[11px] font-medium transition-colors',
            meta.chip,
            meta.text,
          )}
          role="status"
          aria-live="polite"
        >
          <span className="relative flex h-1.5 w-1.5">
            {(status === 'waiting' || status === 'ringing') && (
              <span className={clsx('absolute inline-flex h-full w-full rounded-full opacity-70 animate-ping-soft', meta.dot)} />
            )}
            <span className={clsx('relative inline-flex h-1.5 w-1.5 rounded-full', meta.dot)} />
          </span>
          {meta.label}
        </div>

        <div className="flex items-center gap-2.5 rounded-full border border-white/[.07] bg-white/[.03] py-1 pl-3 pr-1.5">
          {settings.mask ? (
            <EyeOff size={13} className="text-cyan-200/80" />
          ) : (
            <Eye size={13} className="text-slate-400" />
          )}
          <span className="hidden text-[11px] text-slate-400 sm:inline">
            {settings.mask ? '时间已遮挡' : '遮挡时间'}
          </span>
          <Switch checked={settings.mask} onChange={(mask) => update({ mask })} label="遮挡时间" />
        </div>
      </div>
    </header>
  )
}
