import { AnimatePresence, motion, useReducedMotion } from 'motion/react'
import { useCallback, useEffect, useRef, useState } from 'react'

const LOAD_MS = 1250
const HOLD_MS = 200
const WORD = 'PULSERING'
const TRACKING = '0.42em'
const RADIUS = 52
const CIRCUMFERENCE = 2 * Math.PI * RADIUS

function easeInOutCubic(t: number): number {
  return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2
}

export function BootScreen() {
  const [visible, setVisible] = useState(true)
  const [progress, setProgress] = useState(0)
  const reduced = useReducedMotion() === true
  const rafRef = useRef(0)
  const holdRef = useRef<number | undefined>(undefined)
  const finishedRef = useRef(false)

  const finish = useCallback(() => {
    if (finishedRef.current) return
    finishedRef.current = true
    setProgress(1)
    holdRef.current = window.setTimeout(() => setVisible(false), HOLD_MS)
  }, [])

  useEffect(() => {
    const duration = reduced ? 360 : LOAD_MS
    let startedAt: number | null = null

    const tick = (now: number) => {
      if (startedAt === null) startedAt = now
      const t = Math.min(1, (now - startedAt) / duration)
      setProgress(t)
      if (t < 1) rafRef.current = requestAnimationFrame(tick)
      else finish()
    }

    rafRef.current = requestAnimationFrame(tick)
    return () => {
      cancelAnimationFrame(rafRef.current)
      window.clearTimeout(holdRef.current)
    }
  }, [finish, reduced])

  useEffect(() => {
    if (!visible) return
    const previous = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => {
      document.body.style.overflow = previous
    }
  }, [visible])

  const drawn = easeInOutCubic(progress)
  const angle = drawn * Math.PI * 2 - Math.PI / 2
  const headX = 60 + RADIUS * Math.cos(angle)
  const headY = 60 + RADIUS * Math.sin(angle)

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          key="boot"
          data-block-shortcuts="true"
          data-boot-screen="true"
          className="fixed inset-0 z-[100] overflow-hidden bg-[#05070c]"
          style={{ willChange: 'opacity, transform' }}
          initial={reduced ? false : { opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, ease: 'easeOut' }}
          exit={
            reduced
              ? { opacity: 0, transition: { duration: 0.2 } }
              : { opacity: 0, scale: 1.035, transition: { duration: 0.6, ease: [0.32, 0, 0.24, 1] } }
          }
        >
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_52%_44%_at_50%_43%,rgba(125,211,252,.075),transparent_72%)]" />
          <div className="absolute left-1/2 top-0 h-[420px] w-[720px] -translate-x-1/2 bg-[radial-gradient(ellipse_at_top,rgba(165,243,252,.05),transparent_74%)]" />
          <div className="absolute -left-48 top-[-24%] h-[540px] w-[540px] rounded-full bg-sky-400/[.045] blur-[150px]" />
          <div className="absolute -bottom-36 -right-48 h-[580px] w-[580px] rounded-full bg-indigo-500/[.055] blur-[160px]" />
          <div className="noise-layer absolute inset-0" />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_32%,rgba(3,5,10,.82)_100%)]" />
          <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/[.06] to-transparent" />

          <span role="status" className="sr-only">
            正在加载 PulseRing
          </span>

          <motion.div
            className="relative flex min-h-full flex-col items-center justify-center px-6 pb-16 pt-10"
            exit={reduced ? { opacity: 0 } : { opacity: 0, scale: 0.99, filter: 'blur(5px)' }}
            transition={{ duration: 0.4, ease: 'easeIn' }}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.94, filter: 'blur(6px)' }}
              animate={{ opacity: 1, scale: 1, filter: 'blur(0px)' }}
              transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1] }}
              className="relative h-[124px] w-[124px] sm:h-[142px] sm:w-[142px]"
            >
              <div className="animate-breathe absolute inset-0 rounded-full bg-cyan-300/[.06] blur-3xl" />
              <div className="boot-spin absolute inset-[-7px] rounded-full border border-dashed border-white/[.045]" />
              <div className="absolute inset-2 rounded-full border border-white/[.035]" />

              <span className="absolute left-1/2 top-0 h-2 w-px -translate-x-1/2 bg-white/[.12]" />
              <span className="absolute bottom-0 left-1/2 h-2 w-px -translate-x-1/2 bg-white/[.12]" />
              <span className="absolute left-0 top-1/2 h-px w-2 -translate-y-1/2 bg-white/[.12]" />
              <span className="absolute right-0 top-1/2 h-px w-2 -translate-y-1/2 bg-white/[.12]" />

              <svg viewBox="0 0 120 120" className="absolute inset-0 h-full w-full overflow-visible">
                <circle cx="60" cy="60" r={RADIUS} fill="none" stroke="rgba(148,163,184,.1)" strokeWidth="1" />
                <circle
                  cx="60"
                  cy="60"
                  r={RADIUS}
                  fill="none"
                  stroke="url(#bootArc)"
                  strokeWidth="5"
                  strokeLinecap="round"
                  strokeDasharray={CIRCUMFERENCE}
                  strokeDashoffset={CIRCUMFERENCE * (1 - drawn)}
                  transform="rotate(-90 60 60)"
                  opacity="0.16"
                />
                <circle
                  cx="60"
                  cy="60"
                  r={RADIUS}
                  fill="none"
                  stroke="url(#bootArc)"
                  strokeWidth="1.4"
                  strokeLinecap="round"
                  strokeDasharray={CIRCUMFERENCE}
                  strokeDashoffset={CIRCUMFERENCE * (1 - drawn)}
                  transform="rotate(-90 60 60)"
                />
                {drawn > 0.015 && (
                  <g>
                    <circle cx={headX} cy={headY} r="9" fill="url(#bootHalo)" />
                    <circle cx={headX} cy={headY} r="1.2" fill="#f0fdff" />
                  </g>
                )}
                <defs>
                  <linearGradient id="bootArc" x1="8" y1="4" x2="112" y2="116" gradientUnits="userSpaceOnUse">
                    <stop stopColor="#67e8f9" />
                    <stop offset="0.5" stopColor="#818cf8" />
                    <stop offset="1" stopColor="#c084fc" />
                  </linearGradient>
                  <radialGradient id="bootHalo">
                    <stop stopColor="#a5f3fc" stopOpacity="0.32" />
                    <stop offset="1" stopColor="#a5f3fc" stopOpacity="0" />
                  </radialGradient>
                </defs>
              </svg>

              <div className="absolute inset-0 grid place-items-center">
                <motion.div
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.25, duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
                  className="grid h-11 w-11 place-items-center rounded-full border border-white/[.08] bg-white/[.02] shadow-[inset_0_1px_0_rgba(255,255,255,.09),0_0_40px_-12px_rgba(165,243,252,.4)] backdrop-blur-sm"
                >
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden>
                    <circle cx="12" cy="12" r="7.4" stroke="url(#bootMark)" strokeWidth="1" opacity=".8" />
                    <circle cx="12" cy="12" r="2.1" fill="url(#bootMark)" />
                    <defs>
                      <linearGradient id="bootMark" x1="5" y1="5" x2="19" y2="19">
                        <stop stopColor="#ecfeff" />
                        <stop offset="1" stopColor="#a5b4fc" />
                      </linearGradient>
                    </defs>
                  </svg>
                </motion.div>
              </div>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, letterSpacing: '0.86em', filter: 'blur(4px)' }}
              animate={{ opacity: 1, letterSpacing: TRACKING, filter: 'blur(0px)' }}
              transition={{ delay: reduced ? 0 : 0.14, duration: reduced ? 0.01 : 1.15, ease: [0.16, 1, 0.3, 1] }}
              style={{ marginRight: `-${TRACKING}` }}
              className="mt-10 text-[13px] font-light text-[#eef3ff] drop-shadow-[0_0_20px_rgba(191,219,254,.16)] sm:text-[15px]"
            >
              {WORD}
            </motion.h1>

            <motion.div
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: reduced ? 0 : 0.46, duration: reduced ? 0.01 : 0.7, ease: 'easeOut' }}
              className="mt-4 flex items-center gap-4"
            >
              <span className="h-px w-6 bg-gradient-to-r from-transparent to-white/[.16]" />
              <span className="text-[10px] tracking-[0.38em] text-slate-500">随机响铃 · 持续注意</span>
              <span className="h-px w-6 bg-gradient-to-l from-transparent to-white/[.16]" />
            </motion.div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: reduced ? 0 : 0.6, duration: reduced ? 0.01 : 0.6 }}
            className="absolute inset-x-0 bottom-8 text-center text-[8px] tracking-[0.34em] text-slate-700"
          >
            RAINLOVE · FREE &amp; OPEN SOURCE
          </motion.div>

          <motion.button
            type="button"
            onClick={finish}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: reduced ? 0 : 0.55, duration: reduced ? 0.01 : 0.4 }}
            className="absolute right-5 top-5 rounded-full px-2.5 py-1.5 text-[9px] tracking-[0.24em] text-slate-600 transition hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300/40 sm:right-7 sm:top-7"
          >
            跳过
          </motion.button>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
