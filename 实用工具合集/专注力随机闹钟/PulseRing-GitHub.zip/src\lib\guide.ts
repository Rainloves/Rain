export interface GuideStep {
  title: string
  detail: string
}

export interface GuideScenario {
  title: string
  detail: string
}

export const GUIDE_SUBTITLE = '随机听觉提示与持续注意'

export const GUIDE_LEAD =
  '随机响铃不是任务提示，而是一种无信息内容的外部注意支架。它不告诉你该做什么，只用一次轻响，把你从自动化的走神里叫回来。'

export const GUIDE_BACKGROUND: string[] = [
  '在持续注意任务中，心智游移是造成专注水平下降、任务绩效降低的重要原因，随机听觉提示范式常被用于对走神行为进行监测与调控。',
  '早期研究提出，无信息内容的随机提示线索可以作为外部注意控制的辅助手段：在不提供任务相关信息的前提下打断自动化的走神状态，促使个体重新激活目标监控，提升持续注意的稳定性。该方式对注意控制受损群体同样具备改善效果（Manly et al., 2003）。',
  '后续神经层面研究进一步发现，随机提示能够降低自上而下注意控制的认知负荷，充当警觉性注意的外部支持支架，帮助个体以更低的认知成本维持任务警觉（O’Connor et al., 2015）。',
  'Schooler 与 Smallwood 等人围绕心智游移的元觉知理论展开系列研究，指出随机探针范式不仅是测量走神的经典方法，反复触发的自我觉察过程也能够减少无意识走神的发生频率，促进个体对自身注意力状态的监控（Schooler et al., 2007; Smallwood & Schooler, 2011）。',
  '国内相关综述也梳理了随机探针法在走神研究中的应用逻辑，认为注意力调控本质上是对心智游移的抑制与元认知监测（李沁等，2020）。',
]

export const GUIDE_WARNING =
  '现有研究也提示，随机响铃的干预效果存在边界条件：提示密度、刺激强度以及个体唤醒水平都会影响最终结果，不当的听觉刺激反而可能形成新的干扰。'

export const GUIDE_STEPS: GuideStep[] = [
  {
    title: '设定随机区间',
    detail: '例如 3–5 分钟。每一轮都会在区间内重新随机抽取，而不是固定间隔。',
  },
  {
    title: '选择提示音与时长',
    detail: '根据环境安静程度选择音色，并用滑杆调整音量与每次响铃的持续时间。',
  },
  {
    title: '开始并保持任务',
    detail: '点击开始后继续手头的事情。提示响起时，花几秒觉察当前注意状态，再温和地把注意力带回任务。',
  },
  {
    title: '按需遮挡时间',
    detail: '隐藏倒计时与预计响铃时刻，减少盯表与预期带来的干扰；响铃与随机排程不受影响。',
  },
]

export const GUIDE_SCENARIOS: GuideScenario[] = [
  {
    title: '持续注意任务',
    detail: '阅读、写作、编程、网课等需要长时间保持注意力的场景。',
  },
]
