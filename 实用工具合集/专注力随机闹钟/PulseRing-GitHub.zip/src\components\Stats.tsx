import clsx from 'clsx'
import { Bell, Clock, Shuffle, Timer } from 'lucide-react'
import type { ReactNode } from 'react'
import type { BellEngine } from '../hooks/useBellEngine'
import { formatInterval, formatTimeOfDay, formatUptime } from '../lib/format'
import { Card } from './primitives'

interface StatItem {
  icon: ReactNode
  label: string
  value: string
  unit?: string
  hint: string
  numeric: boolean
  tint: string
}

export function Stats({ engine }: { engine: BellEngine }) {
  const { status, rings, uptimeMs, waitMs, planCount, settings, nextAt } = engine
  const masked = settings.mask

  const nextValue = masked
    ? '已遮挡'
    : status === 'ringing'
      ? '响铃中'
      : status === 'waiting' && nextAt !== null
        ? formatTimeOfDay(nextAt)
        : status === 'paused'
          ? '已暂停'
          : '—'

  const items: StatItem[] = [
    {
      icon: <Bell size={13} />,
      label: '已响铃',
      value: String(rings),
      unit: '次',
      hint: '本次会话累计',
      numeric: true,
      tint: 'text-cyan-300/80',
    },
    {
      icon: <Timer size={13} />,
      label: '已运行',
      value: formatUptime(uptimeMs),
      hint: status === 'paused' ? '已暂停计时' : status === 'idle' ? '等待开始' : '不含暂停时间',
      numeric: true,
      tint: 'text-indigo-300/80',
    },
    {
      icon: <Shuffle size={13} />,
      label: '本轮间隔',
      value: masked ? '已遮挡' : status !== 'idle' && waitMs > 0 ? formatInterval(waitMs) : '—',
      hint: '每轮独立随机抽取',
      numeric: false,
      tint: 'text-violet-300/80',
    },
    {
      icon: <Clock size={13} />,
      label: '下次响铃',
      value: nextValue,
      hint: masked ? '时间已遮挡' : `${planCount} 轮已提前排程`,
      numeric: false,
      tint: 'text-amber-300/80',
    },
  ]

  return (
    <Card className="overflow-hidden p-0">
      <div className="grid grid-cols-2 gap-px bg-white/[.055] sm:grid-cols-4">
        {items.map((item) => (
          <div key={item.label} className="flex flex-col gap-2 bg-[#070b12]/85 p-5">
            <div className="flex items-center gap-2 text-[10px] uppercase tracking-[0.18em] text-slate-500">
              <span className={item.tint}>{item.icon}</span>
              {item.label}
            </div>
            <div
              className={clsx(
                'flex items-baseline gap-1',
                item.numeric ? 'digits text-[22px] font-semibold text-white' : 'text-[16px] font-medium text-slate-200',
              )}
            >
              {item.value}
              {item.unit && <span className="text-[11px] font-normal text-slate-500">{item.unit}</span>}
            </div>
            <div className="text-[10px] text-slate-600">{item.hint}</div>
          </div>
        ))}
      </div>
    </Card>
  )
}
