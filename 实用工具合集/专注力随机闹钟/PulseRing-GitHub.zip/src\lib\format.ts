export function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value))
}

export function pad2(value: number): string {
  return String(Math.floor(Math.abs(value))).padStart(2, '0')
}

/** 倒计时：mm:ss，向上取整，避免最后一秒显示 00:00 太久 */
export function formatCountdown(ms: number): string {
  const total = Math.max(0, Math.ceil(ms / 1000))
  const minutes = Math.floor(total / 60)
  const seconds = total % 60
  return `${pad2(minutes)}:${pad2(seconds)}`
}

/** 运行时长：hh:mm:ss */
export function formatUptime(ms: number): string {
  const total = Math.max(0, Math.floor(ms / 1000))
  const hours = Math.floor(total / 3600)
  const minutes = Math.floor((total % 3600) / 60)
  const seconds = total % 60
  return `${pad2(hours)}:${pad2(minutes)}:${pad2(seconds)}`
}

export function formatInterval(ms: number): string {
  const total = Math.max(0, Math.round(ms / 1000))
  const minutes = Math.floor(total / 60)
  const seconds = total % 60
  if (minutes > 0 && seconds > 0) return `${minutes} 分 ${pad2(seconds)} 秒`
  if (minutes > 0) return `${minutes} 分钟`
  return `${seconds} 秒`
}

export function formatTimeOfDay(timestamp: number): string {
  return new Date(timestamp).toLocaleTimeString('zh-CN', { hour12: false })
}

export function formatLogTime(timestamp: number): string {
  return new Date(timestamp).toLocaleTimeString('zh-CN', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })
}
