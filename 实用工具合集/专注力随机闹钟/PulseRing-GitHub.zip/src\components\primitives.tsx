import clsx from 'clsx'
import type { CSSProperties, HTMLAttributes, ReactNode } from 'react'

export function Card({ className, children, ...rest }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={clsx('glass', className)} {...rest}>
      {children}
    </div>
  )
}

export function CardHead({
  icon,
  title,
  hint,
  action,
}: {
  icon: ReactNode
  title: string
  hint?: string
  action?: ReactNode
}) {
  return (
    <div className="flex items-start justify-between gap-3">
      <div className="flex items-center gap-3">
        <div className="grid h-9 w-9 place-items-center rounded-xl border border-white/[.08] bg-white/[.045] text-cyan-200/90 shadow-[inset_0_1px_0_rgba(255,255,255,.08)]">
          {icon}
        </div>
        <div>
          <h2 className="text-[15px] font-semibold tracking-tight text-slate-100">{title}</h2>
          {hint && <p className="mt-0.5 text-[11px] leading-4 text-slate-500">{hint}</p>}
        </div>
      </div>
      {action}
    </div>
  )
}

export function Switch({
  checked,
  onChange,
  label,
}: {
  checked: boolean
  onChange: (value: boolean) => void
  label: string
}) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      aria-label={label}
      onClick={() => onChange(!checked)}
      className={clsx(
        'relative inline-flex h-7 w-12 shrink-0 items-center rounded-full border transition-colors duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300/60 focus-visible:ring-offset-2 focus-visible:ring-offset-[#080b12]',
        checked
          ? 'border-cyan-300/40 bg-cyan-300/20 shadow-[inset_0_0_12px_rgba(103,232,249,.18)]'
          : 'border-white/10 bg-white/[.06]',
      )}
    >
      <span
        className={clsx(
          'absolute left-0.5 grid h-6 w-6 place-items-center rounded-full transition-all duration-300',
          checked
            ? 'translate-x-5 bg-cyan-200 shadow-[0_0_18px_rgba(103,232,249,.55)]'
            : 'translate-x-0 bg-slate-400',
        )}
      />
    </button>
  )
}

export function SliderRow({
  icon,
  label,
  value,
  suffix,
  min,
  max,
  step,
  onChange,
}: {
  icon: ReactNode
  label: string
  value: number
  suffix: string
  min: number
  max: number
  step: number
  onChange: (value: number) => void
}) {
  const fill = max > min ? ((value - min) / (max - min)) * 100 : 0
  return (
    <div>
      <div className="flex items-center justify-between">
        <span className="flex items-center gap-2 text-[12px] text-slate-400">
          {icon}
          {label}
        </span>
        <span className="rounded-md border border-white/[.07] bg-white/[.04] px-2 py-0.5 text-[11px] font-medium tabular-nums text-slate-200">
          {value}
          {suffix}
        </span>
      </div>
      <input
        className="range-input mt-2"
        type="range"
        aria-label={label}
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(event) => onChange(Number(event.target.value))}
        style={{ '--fill': `${fill}%` } as CSSProperties}
      />
    </div>
  )
}
