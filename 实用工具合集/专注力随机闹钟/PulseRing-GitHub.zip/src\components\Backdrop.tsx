export function Backdrop() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 overflow-hidden">
      <div className="absolute inset-0 bg-[#05070c]" />
      <div
        className="aurora-blob left-[-14%] top-[-24%] h-[48rem] w-[48rem] bg-[radial-gradient(circle_at_center,rgba(56,189,248,.24),transparent_62%)]"
        style={{ animationDelay: '-8s' }}
      />
      <div className="aurora-blob right-[-16%] top-[2%] h-[44rem] w-[44rem] bg-[radial-gradient(circle_at_center,rgba(129,140,248,.22),transparent_62%)]" />
      <div
        className="aurora-blob bottom-[-34%] left-[18%] h-[46rem] w-[46rem] bg-[radial-gradient(circle_at_center,rgba(45,212,191,.14),transparent_62%)]"
        style={{ animationDelay: '-16s' }}
      />
      <div className="absolute inset-0 grid-lines" />
      <div className="absolute inset-0 noise-layer" />
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-cyan-200/25 to-transparent" />
    </div>
  )
}
