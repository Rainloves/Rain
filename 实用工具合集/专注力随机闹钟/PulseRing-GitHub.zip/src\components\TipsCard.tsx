import { Dices, ShieldCheck, Sparkles, Waves } from 'lucide-react'
import type { BellEngine } from '../hooks/useBellEngine'
import { Card, CardHead } from './primitives'

const ITEMS = [
  {
    icon: Dices,
    tint: 'text-cyan-300/80',
    border: 'border-cyan-300/15 bg-cyan-300/[.05]',
    title: '真随机抽取',
    desc: '每轮使用 crypto 随机数重新抽取，与上一轮完全独立。',
  },
  {
    icon: Waves,
    tint: 'text-indigo-300/80',
    border: 'border-indigo-300/15 bg-indigo-300/[.05]',
    title: '提前排程',
    desc: '未来 12 分钟的铃声已写入音频时间轴，后台标签页同样准时。',
  },
  {
    icon: ShieldCheck,
    tint: 'text-emerald-300/80',
    border: 'border-emerald-300/15 bg-emerald-300/[.05]',
    title: '本地优先',
    desc: '音频在本机实时合成，偏好仅保存在浏览器 localStorage。',
  },
]

export function TipsCard({ engine }: { engine: BellEngine }) {
  const { settings, planCount } = engine

  return (
    <Card className="flex h-full flex-col p-6">
      <CardHead icon={<Sparkles size={16} />} title="运行机制" hint="为什么它既随机又准时" />

      <ul className="mt-5 space-y-3">
        {ITEMS.map((item) => {
          const Icon = item.icon
          return (
            <li key={item.title} className="flex items-start gap-3">
              <div className={`grid h-8 w-8 shrink-0 place-items-center rounded-lg border ${item.border} ${item.tint}`}>
                <Icon size={14} />
              </div>
              <div>
                <p className="text-[12px] font-medium text-slate-200">{item.title}</p>
                <p className="mt-0.5 text-[10px] leading-4 text-slate-500">{item.desc}</p>
              </div>
            </li>
          )
        })}
      </ul>

      <div className="mt-auto space-y-2 border-t border-white/[.05] pt-4 text-[10px] text-slate-600">
        <div className="flex items-center justify-between">
          <span>当前区间</span>
          <span className="tabular-nums text-slate-400">
            {Math.min(settings.loMin, settings.hiMin)} – {Math.max(settings.loMin, settings.hiMin)} 分钟
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span>已排程</span>
          <span className="tabular-nums text-slate-400">{planCount} 轮 · 每次 {settings.ringSec} 秒</span>
        </div>
        <p className="leading-4 text-slate-600">开启遮挡后只是隐藏时间显示，响铃与排程不受任何影响。</p>
      </div>
    </Card>
  )
}
