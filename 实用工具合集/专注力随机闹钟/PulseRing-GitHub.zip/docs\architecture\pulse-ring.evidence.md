# PulseRing 架构证据索引

- 基线：2026-11-08 的工作区快照（该项目不是 git 仓库，无 commit 可作为基线标识）。
- 状态：全部为 **current-state（当前状态）**，不存在 target / proposed 节点。
- 置信度：`high` = 代码 / 配置直接证明；`medium` = 多处信号一致但无直接来源；`low` = 由文案、命名或用户意图推断；`unknown` = 留待验证。
- 对应模型：`pulse-ring.structurizr.dsl`（C4 上下文 / 容器 / 组件）、`pulse-ring-build.dot`（构建与交付）。

---

## 1. 系统与容器

| ID | 元素 | 证据 | 置信度 |
| --- | --- | --- | --- |
| `user` | 使用者 | 界面文案“随机响铃 · 持续专注”、使用说明与研究背景；具体人群由产品意图推断（`src/lib/guide.ts:11-16`、`src/components/BootScreen.tsx:197`） | low |
| `pulseRing` | PulseRing 随机响铃提醒器 | `index.html:15-22`、`src/App.tsx:23-95` | high |
| `pulseRing.app` | 单文件 Web 应用 | `package.json:6-20`、`vite.config.ts:5-11`、`src/main.tsx:1-11` | high |
| `browser.webAudio` | Web Audio API | `src/lib/audio.ts:19-37`（AudioContext 创建与 resume）、`:47-93`（振荡器排程） | high |
| `browser.prefs` | localStorage | `src/lib/settings.ts:25`（键 `pulse-ring.prefs.v2`）、`:36-52`（读写） | high |
| `browser.webCrypto` | Web Crypto API | `src/lib/random.ts:4-8`（`crypto.getRandomValues`） | high |

**边界证据**：全仓库检索 `fetch(` / `XMLHttpRequest` / `axios` / `WebSocket` / `sendBeacon` 均无结果，运行时不依赖后端或网络。

---

## 2. 组件（`pulseRing.app` 内部）

| ID | 组件 | 职责 | 证据 | 置信度 |
| --- | --- | --- | --- | --- |
| `shell` | App 外壳 | 页面骨架、栅格布局、组件组装 | `src/App.tsx:23-95` | high |
| `cards` | 功能卡片 | Header / Stage / RangeCard / AdvancedCard / SoundRack / Stats / LogPanel / TipsCard | `src/components/Header.tsx:1-10`、`Stage.tsx:9-18`、`RangeCard.tsx:1-12`、`AdvancedCard.tsx:1-8`、`SoundRack.tsx:1-8`、`Stats.tsx:1-8`、`LogPanel.tsx:1-6`、`TipsCard.tsx:1-5` | high |
| `overlays` | 启动与弹层 | BootScreen / GuideDialog / ContactDialog / Backdrop | `src/components/BootScreen.tsx:14-46`、`GuideDialog.tsx:1-10`、`ContactDialog.tsx:8-30`、`Backdrop.tsx:1-19` | high |
| `engine` | 提醒引擎 | 状态机、前瞻排程、tick、暂停恢复、快捷键、标题 | `src/hooks/useBellEngine.ts:8`、`:50-53`、`:87-128`、`:150-190`、`:192-317` | high |
| `audioEngine` | 音频合成器 | AudioContext、主音量、振荡器排程与停止 | `src/lib/audio.ts:9-117` | high |
| `presets` | 音色配方 | 12 种提示音参数与试听元数据 | `src/lib/sounds.ts:1-30`、`:192`（`SOUND_MAP`），`grep` 计数 12 个预设 | high |
| `persistence` | 偏好持久化 | 默认值、归一化、读取、保存、区间换算 | `src/lib/settings.ts:4-20`、`:27-59` | high |
| `utils` | 随机与格式化 | crypto 随机数、倒计时 / 时长 / 区间格式化 | `src/lib/random.ts:1-10`、`src/lib/format.ts:1-40` | high |
| `guideContent` | 说明文案数据 | 使用说明、研究背景与引用 | `src/lib/guide.ts:1-16`、`src/components/GuideDialog.tsx:1-10` | high |
| `qrAsset` | 作者二维码 | 微信二维码图片，构建时内联 | `src/components/ContactDialog.tsx:4`、`src/assets/wechat-qr.jpg` | high |

> 说明：`cards` 在模型中聚合为单一组件，避免组件视图被 8 个展示卡片撑得无法阅读；单个卡片的证据见上表。

---

## 3. 关键关系

| 关系 | 类型 | 协议 / 机制 | 证据 | 置信度 |
| --- | --- | --- | --- | --- |
| `shell → cards / overlays / engine` | 组装 / 调用 | React props、Hook | `src/App.tsx:24-67`、`:91-92` | high |
| `cards → engine` | 读取状态、派发操作 | `BellEngine` 返回值 | `src/hooks/useBellEngine.ts:443-467`；各卡片 `engine` 入参 | high |
| `cards → utils` | 编译期 import | TypeScript | `Stage.tsx:4`、`RangeCard.tsx:5`、`Stats.tsx:6`、`LogPanel.tsx:4` | high |
| `cards → presets` | 编译期 import | TypeScript | `SoundRack.tsx:4`、`AdvancedCard.tsx:3` | high |
| `overlays → guideContent / qrAsset` | 编译期 import | TypeScript / Vite 资源导入 | `GuideDialog.tsx:4-10`、`ContactDialog.tsx:4` | high |
| `engine → audioEngine` | 运行时调用 | 方法调用 | `useBellEngine.ts:87-98`、`:130-148`、`:293-310` | high |
| `engine → persistence` | 运行时调用 | 函数调用 | `useBellEngine.ts:56`、`:363-377` | high |
| `engine → presets / utils` | 编译期 import | TypeScript | `useBellEngine.ts:2-6` | high |
| `audioEngine → presets` | 编译期 import | 类型 + 配方数据 | `src/lib/audio.ts:1`、`:47-93` | high |
| `persistence → presets / utils` | 编译期 import | TypeScript | `src/lib/settings.ts:1-2` | high |
| `persistence → browser.prefs` | 读写 | `localStorage` | `src/lib/settings.ts:36-52` | high |
| `audioEngine → browser.webAudio` | 运行时调用 | `AudioContext` | `src/lib/audio.ts:19-37`、`:47-93` | high |
| `utils → browser.webCrypto` | 运行时调用 | `crypto.getRandomValues` | `src/lib/random.ts:4-8` | high |
| `user → pulseRing` | 使用 | 浏览器界面 | `src/App.tsx:31-68` | medium |

---

## 4. 运行时行为证据

### 4.1 状态机与调度

- 状态集合：`idle | waiting | ringing | paused`（`src/hooks/useBellEngine.ts:8`）。
- 前瞻窗口 `LOOKAHEAD_MS = 12 分钟`、最多 `MAX_PLANNED = 12` 个事件、轮询 `TICK_MS = 200`（同文件 `:50-53`）。
- 每轮在 `[lo, hi]` 内抽取随机等待，事件首尾相接（`:100-128`）。
- 音频在 `AudioContext` 时间轴上提前排程，而非依赖 `setTimeout`（`src/lib/audio.ts:5-8`、`:47-93`）。
- 标签页重新可见时立即补一次 tick（`:384-390`）；标题栏显示倒计时或“正在响铃”（`:392-403`）。
- 暂停会保留剩余时长与阶段，恢复时重建事件（`:218-291`）。

### 4.2 设置与持久化

- 默认值：3–5 分钟、15 秒、经典滴滴、音量 0.65、不遮挡（`src/lib/settings.ts:13-20`）。
- 存储键固定为 `pulse-ring.prefs.v2`，读写均包裹 `try/catch`（`:25`、`:36-52`）。
- 设置变化后写入 localStorage，并在音色变化时重排、区间 / 时长变化时保留队首重排（`useBellEngine.ts:363-377`、`:130-148`）。

### 4.3 交互与可访问性

- 快捷键：Space 开始 / 暂停、Esc 停止、M 切换遮挡；输入框内与带 `data-block-shortcuts` 的弹层中禁用（`useBellEngine.ts:333-360`）。
- 弹层具备 Esc / 遮罩关闭、焦点恢复、Tab 焦点圈定与滚动锁（`ContactDialog.tsx`、`GuideDialog.tsx`）。
- 启动页提供跳过按钮与 `role="status"` 文本（`BootScreen.tsx:89-91`、`:211-221`）。

### 4.4 单文件构建

- 构建链：`tsc --noEmit && vite build && node scripts/emit-single-file.mjs`（`package.json:8`）。
- `base: './'` + `assetsInlineLimit: 2 MB`（`vite.config.ts:5-11`），二维码 78 KB 被内联。
- 脚本把 CSS / JS 写回 HTML、移除 `modulepreload`，输出根目录 `PulseRing.html`（`scripts/emit-single-file.mjs:5-30`）。
- 当前产物：`PulseRing.html`，621,473 字节（约 607 KB）。

---

## 5. 假设、未知与验证任务

| 项 | 状态 | 说明 | 下一步验证 |
| --- | --- | --- | --- |
| 目标用户 | low | 文案指向“专注 / 节律”，具体人群未在仓库中定义 | 与作者确认受众画像 |
| 分发方式 | unknown | 用户提出可上传 GitHub，但仓库内没有 Pages / CI 配置 | 若发布 GitHub Pages，补充 CI 与相对路径验证 |
| 浏览器兼容性 | unknown | 依赖 Web Audio；仅回退 `webkitAudioContext`，无自动化测试 | 在 Safari / iOS / Firefox 实测启动、排程与后台响铃 |
| 自动化测试 | unknown | 仓库内无测试框架与测试文件 | 若要长期维护，补充调度与持久化的单元测试 |
| 离线能力 | high（无） | 无 Service Worker / manifest；完全离线依赖单文件本身 | 无需动作，除非要求可安装 PWA |
| 内存中的双状态 | high | React state 与 `H` ref 并存，`H` 承载调度真值（`useBellEngine.ts:68-78`） | 修改引擎时保持两者同步 |

---

## 6. 复核方式

```bash
# 确认无网络依赖
rg "fetch\(|XMLHttpRequest|axios|WebSocket|sendBeacon" src

# 确认音频与持久化边界
rg "AudioContext|localStorage|getRandomValues" src

# 确认单文件产物
ls -l PulseRing.html
```
