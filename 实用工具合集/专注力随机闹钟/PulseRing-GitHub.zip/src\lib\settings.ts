import { clamp } from './format'
import { SOUND_MAP, type SoundId } from './sounds'

export interface Settings {
  loMin: number
  hiMin: number
  ringSec: number
  soundId: SoundId
  volume: number
  mask: boolean
}

export const DEFAULT_SETTINGS: Settings = {
  loMin: 3,
  hiMin: 5,
  ringSec: 15,
  soundId: 'classic',
  volume: 0.65,
  mask: false,
}

export const MIN_MINUTES = 0.1
export const MAX_MINUTES = 600

const STORAGE_KEY = 'pulse-ring.prefs.v2'

export function normalizeSettings(input: Partial<Settings>): Settings {
  const loMin = clamp(Number(input.loMin ?? DEFAULT_SETTINGS.loMin) || DEFAULT_SETTINGS.loMin, MIN_MINUTES, MAX_MINUTES)
  const hiMin = clamp(Number(input.hiMin ?? DEFAULT_SETTINGS.hiMin) || DEFAULT_SETTINGS.hiMin, MIN_MINUTES, MAX_MINUTES)
  const ringSec = clamp(Math.round(Number(input.ringSec ?? DEFAULT_SETTINGS.ringSec) || DEFAULT_SETTINGS.ringSec), 3, 120)
  const volume = clamp(Number(input.volume ?? DEFAULT_SETTINGS.volume), 0, 1)
  const soundId: SoundId = input.soundId && SOUND_MAP[input.soundId] ? input.soundId : DEFAULT_SETTINGS.soundId
  return { loMin, hiMin, ringSec, soundId, volume, mask: Boolean(input.mask) }
}

export function loadSettings(): Settings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY)
    if (!raw) return DEFAULT_SETTINGS
    return normalizeSettings(JSON.parse(raw) as Partial<Settings>)
  } catch {
    return DEFAULT_SETTINGS
  }
}

export function saveSettings(settings: Settings): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings))
  } catch {
    /* 隐私模式下 localStorage 可能不可用 */
  }
}

/** 无论两个输入谁大谁小，都按从小到大作为随机区间 */
export function rangeMs(settings: Settings): { lo: number; hi: number } {
  const a = settings.loMin * 60_000
  const b = settings.hiMin * 60_000
  return { lo: Math.min(a, b), hi: Math.max(a, b) }
}
