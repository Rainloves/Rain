import { readFileSync, writeFileSync } from 'node:fs'
import { join, resolve } from 'node:path'

const distDir = resolve('dist')
let html = readFileSync(join(distDir, 'index.html'), 'utf8')

const external = (url) => /^(https?:|data:|\/\/)/.test(url)
const resolveAsset = (url) => join(distDir, url.replace(/^\.?\//, '').split(/[?#]/)[0])

html = html.replace(/<link\b[^>]*rel="stylesheet"[^>]*>/g, (tag) => {
  const href = tag.match(/href="([^"]+)"/)?.[1]
  if (!href || external(href)) return tag
  return `<style>\n${readFileSync(resolveAsset(href), 'utf8')}\n</style>`
})

html = html.replace(/<script\b[^>]*src="([^"]+)"[^>]*><\/script>/g, (tag, src) => {
  if (external(src)) return tag
  const code = readFileSync(resolveAsset(src), 'utf8').replace(/<\/script/gi, '<\\/script')
  return `<script type="module">\n${code}\n</script>`
})

html = html.replace(/<link\b[^>]*rel="modulepreload"[^>]*>\s*/g, '')

writeFileSync('PulseRing.html', html, 'utf8')
console.log(`PulseRing.html · ${(Buffer.byteLength(html) / 1024).toFixed(0)} KB · 单文件，可直接双击打开`)
