import { AnimatePresence, motion } from 'motion/react'
import { Check, Copy, Mail, MessageCircle, QrCode, Sparkles, X } from 'lucide-react'
import { useCallback, useEffect, useRef, useState } from 'react'
import qrImage from '../assets/wechat-qr.jpg'

const EMAIL = 'rain9630@outlook.com'

export function ContactDialog() {
  const [open, setOpen] = useState(false)
  const [copied, setCopied] = useState(false)
  const triggerRef = useRef<HTMLButtonElement>(null)
  const closeRef = useRef<HTMLButtonElement>(null)
  const timerRef = useRef<number | undefined>(undefined)

  const close = useCallback(() => {
    setOpen(false)
    triggerRef.current?.focus()
  }, [])

  useEffect(() => {
    if (open) closeRef.current?.focus()
  }, [open])

  useEffect(() => {
    if (!open) return
    const previousOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.preventDefault()
        close()
      }
    }
    window.addEventListener('keydown', onKeyDown)

    return () => {
      document.body.style.overflow = previousOverflow
      window.removeEventListener('keydown', onKeyDown)
    }
  }, [open, close])

  useEffect(() => () => window.clearTimeout(timerRef.current), [])

  const copyEmail = useCallback(async () => {
    try {
      await navigator.clipboard.writeText(EMAIL)
    } catch {
      const area = document.createElement('textarea')
      area.value = EMAIL
      area.style.position = 'fixed'
      area.style.opacity = '0'
      document.body.appendChild(area)
      area.select()
      document.execCommand('copy')
      area.remove()
    }
    setCopied(true)
    window.clearTimeout(timerRef.current)
    timerRef.current = window.setTimeout(() => setCopied(false), 1800)
  }, [])

  return (
    <>
      <motion.button
        ref={triggerRef}
        type="button"
        aria-label="打开作者联系方式"
        onClick={() => setOpen(true)}
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.62, duration: 0.5, ease: 'easeOut' }}
        className="group fixed bottom-5 left-5 z-40 inline-flex items-center gap-2 rounded-full border border-white/[.1] bg-[#0a101b]/85 p-2 text-[11px] font-medium text-slate-300 shadow-[0_20px_45px_-18px_rgba(0,0,0,.95)] backdrop-blur-xl transition hover:border-cyan-300/35 hover:text-cyan-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300/50 sm:bottom-6 sm:left-6 sm:pr-4"
      >
        <span className="grid h-8 w-8 place-items-center rounded-full bg-cyan-300/10 text-cyan-200 shadow-[inset_0_1px_0_rgba(255,255,255,.08)] transition group-hover:bg-cyan-300/15">
          <MessageCircle size={14} />
        </span>
        <span className="hidden sm:inline">联系作者</span>
      </motion.button>

      <AnimatePresence>
        {open && (
          <motion.div
            className="fixed inset-0 z-50 flex items-end justify-center p-3 sm:items-center sm:p-6"
            data-block-shortcuts="true"
          >
            <motion.div
              className="absolute inset-0 bg-[#02040a]/75 backdrop-blur-md"
              onClick={close}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25 }}
            />

            <motion.div
              role="dialog"
              aria-modal="true"
              aria-labelledby="contact-title"
              className="glass relative flex max-h-[88vh] w-full max-w-xl flex-col overflow-hidden"
              initial={{ opacity: 0, y: 26, scale: 0.985 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 18, scale: 0.985 }}
              transition={{ type: 'spring', stiffness: 280, damping: 28 }}
              onKeyDown={(event) => {
                if (event.key !== 'Tab') return
                const focusables = event.currentTarget.querySelectorAll<HTMLElement>(
                  'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])',
                )
                if (focusables.length === 0) return
                const first = focusables[0]
                const last = focusables[focusables.length - 1]
                if (event.shiftKey && document.activeElement === first) {
                  event.preventDefault()
                  last.focus()
                } else if (!event.shiftKey && document.activeElement === last) {
                  event.preventDefault()
                  first.focus()
                }
              }}
            >
              <div className="flex items-start justify-between gap-4 border-b border-white/[.06] px-6 pb-5 pt-6">
                <div className="flex items-start gap-3.5">
                  <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-cyan-300/20 bg-cyan-300/[.08] text-cyan-200 shadow-[inset_0_1px_0_rgba(255,255,255,.08)]">
                    <MessageCircle size={17} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h2 id="contact-title" className="text-[16px] font-semibold tracking-tight text-white">
                        联系作者
                      </h2>
                      <span className="rounded-md border border-white/[.08] bg-white/[.04] px-1.5 py-0.5 text-[9px] tracking-[0.14em] text-slate-500">
                        AUTHOR
                      </span>
                    </div>
                    <p className="mt-0.5 text-[11px] text-slate-500">微信二维码 · 邮箱</p>
                  </div>
                </div>
                <button
                  ref={closeRef}
                  type="button"
                  onClick={close}
                  aria-label="关闭联系方式"
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-white/[.08] bg-white/[.03] text-slate-400 transition hover:border-white/15 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300/50"
                >
                  <X size={15} />
                </button>
              </div>

              <div className="min-h-0 flex-1 overflow-y-auto px-6 py-5">
                <div className="grid gap-4 sm:grid-cols-[208px_1fr]">
                  <div>
                    <div className="relative overflow-hidden rounded-2xl border border-white/[.1] bg-white p-3 shadow-[0_26px_60px_-32px_rgba(0,0,0,.95)]">
                      <img
                        src={qrImage}
                        alt="Yoshino 的微信二维码"
                        width={480}
                        height={480}
                        className="block w-full rounded-xl"
                      />
                    </div>
                    <div className="mt-2.5 flex items-center justify-between gap-2 px-0.5">
                      <span className="text-[10px] text-slate-400">微信 · Yoshino</span>
                      <span className="inline-flex items-center gap-1 text-[10px] text-cyan-300/70">
                        <QrCode size={11} />
                        扫码添加
                      </span>
                    </div>
                  </div>

                  <div className="flex flex-col gap-3">
                    <div className="rounded-2xl border border-white/[.06] bg-white/[.02] p-4">
                      <div className="flex items-center gap-2 text-[9px] font-semibold tracking-[0.18em] text-slate-500">
                        <Mail size={12} className="text-cyan-300/70" />
                        EMAIL
                      </div>
                      <a
                        href={`mailto:${EMAIL}`}
                        className="mt-2 block break-all text-[13px] font-medium text-slate-100 transition hover:text-cyan-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300/50"
                      >
                        {EMAIL}
                      </a>
                      <button
                        type="button"
                        onClick={copyEmail}
                        className="mt-3 inline-flex h-8 items-center gap-1.5 rounded-lg border border-white/[.09] bg-white/[.04] px-2.5 text-[10px] text-slate-300 transition hover:border-cyan-300/30 hover:bg-cyan-300/[.06] hover:text-cyan-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300/50"
                      >
                        {copied ? (
                          <>
                            <Check size={11} className="text-emerald-300" />
                            已复制
                          </>
                        ) : (
                          <>
                            <Copy size={11} />
                            复制邮箱
                          </>
                        )}
                      </button>
                    </div>

                    <div className="rounded-2xl border border-white/[.06] bg-white/[.02] p-4">
                      <p className="text-[11px] leading-5 text-slate-400">
                        微信扫码添加好友，或直接发送邮件。欢迎交流使用体验、改进建议，以及更多适合随机提示的使用场景。
                      </p>
                      <p className="mt-2.5 flex items-center gap-1.5 text-[10px] text-slate-600">
                        <Sparkles size={11} />
                        PulseRing · 免费开源
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex flex-col gap-1.5 border-t border-white/[.06] px-6 py-4 text-[10px] text-slate-600 sm:flex-row sm:items-center sm:justify-between">
                <span>以上为作者本人联系方式</span>
                <span className="flex items-center gap-1.5">
                  <kbd className="kbd">Esc</kbd> 关闭
                </span>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
