workspace "PulseRing 随机响铃提醒器" "PulseRing 当前状态（current-state）C4 模型：纯前端、单文件交付的随机响铃提醒器。" {

    !identifiers hierarchical

    model {
        user = person "使用者" "需要随机节奏提醒的专注或学习用户（受众为推断）。" {
            tags "Inferred"
        }

        pulseRing = softwareSystem "PulseRing 随机响铃提醒器" "在自定义时间区间内的随机时刻响铃，帮助保持专注节律；无后端、无网络请求。" {
            app = container "单文件 Web 应用" "React 19 单页应用：界面、计时状态机与音频排程全部在浏览器内运行。" "React 19 + TypeScript + Vite + Tailwind CSS v4" {
                shell = component "App 外壳" "页面骨架、栅格布局与组件组装。" "React"
                cards = component "功能卡片" "Header / Stage / RangeCard / AdvancedCard / SoundRack / Stats / LogPanel / TipsCard。" "React"
                overlays = component "启动与弹层" "BootScreen / GuideDialog / ContactDialog / Backdrop。" "React + Motion"
                engine = component "提醒引擎" "idle / waiting / ringing / paused 状态机，12 分钟前瞻排程，200ms tick，快捷键与标题更新。" "React Hook (useBellEngine)"
                audioEngine = component "音频合成器" "AudioContext、主音量与振荡器排程。" "Web Audio wrapper"
                presets = component "音色配方" "12 种提示音的振荡器参数、循环长度与试听元数据。" "TypeScript data"
                persistence = component "偏好持久化" "默认值、归一化、读取与保存。" "localStorage adapter"
                utils = component "随机与格式化" "crypto 随机数、区间换算与时间格式化。" "TypeScript"
                guideContent = component "说明文案数据" "使用说明、研究背景与引用内容。" "TypeScript data"
                qrAsset = component "作者二维码" "微信二维码 JPEG，构建时内联为 base64 data URI。" "JPEG asset"
            }
        }

        browser = softwareSystem "浏览器运行时" "宿主提供的平台能力，不属于项目代码。" {
            webAudio = container "Web Audio API" "AudioContext 时间轴与振荡器合成。" "Browser API" {
                tags "External"
            }
            prefs = container "localStorage" "以 pulse-ring.prefs.v2 为键保存偏好。" "Browser Storage" {
                tags "Database"
            }
            webCrypto = container "Web Crypto API" "crypto.getRandomValues 提供随机源。" "Browser API" {
                tags "External"
            }
        }

        # --- 系统边界 ---
        user -> pulseRing "在浏览器中打开并使用"

        # --- 组件关系（编译期 import / 运行时调用） ---
        pulseRing.app.shell -> pulseRing.app.cards "组装功能卡片"
        pulseRing.app.shell -> pulseRing.app.overlays "挂载启动动画与弹层"
        pulseRing.app.shell -> pulseRing.app.engine "调用 useBellEngine 获取状态与操作"

        pulseRing.app.cards -> pulseRing.app.engine "读取状态 / 派发操作与设置"
        pulseRing.app.cards -> pulseRing.app.utils "格式化时间与区间"
        pulseRing.app.cards -> pulseRing.app.presets "显示音色名称与试听"

        pulseRing.app.overlays -> pulseRing.app.guideContent "渲染使用说明"
        pulseRing.app.overlays -> pulseRing.app.qrAsset "展示作者二维码"

        pulseRing.app.engine -> pulseRing.app.audioEngine "排程与停止振荡器"
        pulseRing.app.engine -> pulseRing.app.persistence "加载与保存偏好"
        pulseRing.app.engine -> pulseRing.app.presets "读取音色配方"
        pulseRing.app.engine -> pulseRing.app.utils "随机间隔与格式化"

        pulseRing.app.audioEngine -> pulseRing.app.presets "按配方合成提示音"
        pulseRing.app.persistence -> pulseRing.app.presets "校验音色 ID"
        pulseRing.app.persistence -> pulseRing.app.utils "clamp 与区间换算"

        # --- 跨系统边界 ---
        pulseRing.app.persistence -> browser.prefs "读写偏好设置" "localStorage"
        pulseRing.app.audioEngine -> browser.webAudio "提前排程振荡器" "AudioContext"
        pulseRing.app.utils -> browser.webCrypto "获取密码学随机数" "getRandomValues"
    }

    views {
        systemContext pulseRing "SystemContext" "使用者、PulseRing 与宿主平台能力。" {
            include *
            autoLayout tb
        }

        container pulseRing "Containers" "单文件应用容器与浏览器平台能力。" {
            include *
            autoLayout tb
        }

        component pulseRing.app "Components" "单文件应用内部组件及其依赖。" {
            include *
            autoLayout tb
        }

        styles {
            element "Person" {
                shape person
                background #0e7490
                color #ffffff
            }
            element "Software System" {
                background #0f172a
                color #e2e8f0
            }
            element "Container" {
                background #155e75
                color #ffffff
            }
            element "Component" {
                background #1e293b
                color #e2e8f0
            }
            element "Database" {
                shape cylinder
                background #4338ca
                color #ffffff
            }
            element "External" {
                background #475569
                color #f1f5f9
            }
            element "Inferred" {
                background #7c2d12
                color #fed7aa
            }
            relationship {
                color #94a3b8
                thickness 1.5
            }
        }
    }
}
