# PulseRing 架构（当前状态）

> 建模日期：2026-11-08 · 范围：`src/` 与构建脚本的**当前实现** · 不含目标架构与改进建议
>
> 建模方式：`system-modeler`（主场景）+ `c4model`（上下文 / 容器 / 组件）+ `graphviz`（构建交付）

## 一页读懂

PulseRing 是一个**纯前端、可单文件分发**的随机响铃提醒器：

1. **边界**：只有浏览器内的一个 React 19 单页应用，没有后端、没有网络请求；设置写入 `localStorage`，提示音由 Web Audio API 在本机实时合成。
2. **核心循环**：界面 → `useBellEngine`（状态机）→ 在 12 分钟窗口内预先排程随机响铃 → 音频振荡器直接排在 `AudioContext` 时间轴上；200ms 一次的 tick 只负责推进展示与状态。
3. **交付形态**：Vite 打包时把二维码等资源内联进 JS，随后 `emit-single-file.mjs` 把 CSS / JS 全部写回 HTML，产出可直接双击打开的 `PulseRing.html`。

## 交付物

| 文件 | 回答的问题 |
| --- | --- |
| `pulse-ring.structurizr.dsl` | 系统上下文、运行时容器、应用内部组件及依赖（C4 唯一事实源） |
| `pulse-ring-build.dot` | 开发机上的构建与单文件交付链路（非运行时） |
| `pulse-ring.evidence.md` | 每个节点 / 关系的代码证据、置信度、假设与未知项 |
| `README.md` | 本说明：范围、阅读顺序、查看方式与维护约定 |

## 阅读顺序

1. **先看上下文**（`SystemContext`）：使用者 → PulseRing → 浏览器平台能力。
2. **再看容器**（`Containers`）：单文件应用，以及 `Web Audio API`、`localStorage`、`Web Crypto API` 三个宿主容器。
3. **最后看组件**（`Components`）：App 外壳、功能卡片、启动与弹层、提醒引擎、音频合成器、音色配方、偏好持久化、随机与格式化、说明文案、二维码资源。
4. 需要了解单文件怎么来的，再看 `pulse-ring-build.dot`。

## 关键结构

### 应用外壳与展示层

`App.tsx` 是唯一组装点：调用一次 `useBellEngine()`，把同一个 `engine` 对象分发给 Header、Stage、RangeCard、AdvancedCard、SoundRack、Stats、LogPanel、TipsCard，并挂载 BootScreen、GuideDialog、ContactDialog、Backdrop。展示组件不持有调度状态。

### 提醒引擎

`useBellEngine` 是运行时的核心，负责：

- `idle / waiting / ringing / paused` 四态切换；
- 按 `loMin–hiMin` 随机抽取等待时长，事件首尾相接；
- 提前 12 分钟、最多 12 个事件排程到音频层；
- 暂停时保留“等待/响铃”阶段与剩余时长，恢复后重建事件；
- 快捷键（Space / Esc / M）、页面标题倒计时、设置变更后的重排。

调度真值放在 `H` ref 中，React state 只承载渲染所需的快照（`src/hooks/useBellEngine.ts:68-78`）。

### 音频与时间轴

`BellAudio` 持有 `AudioContext` 与主增益，`schedule()` 把每个音符的 `OscillatorNode` 直接排在 `ctx` 时间轴上。这样即使标签页在后台、`setInterval` 被浏览器节流，到点的声音仍然准确（`src/lib/audio.ts:5-8`、`:47-93`）。

12 种提示音是纯数据配方（频率、时长、波形、循环长度），没有外部音频文件（`src/lib/sounds.ts`）。

### 数据与外部能力

- 偏好键：`pulse-ring.prefs.v2`，读取时会做归一化与兜底（`src/lib/settings.ts:25-52`）。
- 随机源：优先 `crypto.getRandomValues`，不可用时退回 `Math.random`（`src/lib/random.ts`）。
- 除以上三项浏览器能力外，没有其他外部依赖。

## 置信度与缺口

- 受众画像、GitHub Pages 等具体分发方式、跨浏览器兼容性属于**推断或未知**，详见 `pulse-ring.evidence.md` 第 5 节。
- 仓库内没有自动化测试与 CI 配置；模型只描述现有代码，不评价工程质量。

## 查看方式

- **C4 模型**：在 Qoder 中用 Structurizr DSL 视图打开 `pulse-ring.structurizr.dsl`。
- **DOT 图**：用 Qoder 的 DOT 格式视图打开 `pulse-ring-build.dot`；本机未安装 Graphviz，如需 SVG 可先安装后执行：

```bash
dot -Tsvg docs/architecture/pulse-ring-build.dot -o docs/architecture/pulse-ring-build.svg
```

## 维护约定

- 新增 `src/lib` 模块或新弹层时，同步更新 DSL 的组件与关系，再更新 `pulse-ring.evidence.md` 的 `sourceRefs`。
- 组件 ID 保持稳定（`shell`、`cards`、`engine`…），方便后续做依赖影响分析。
- 框图是派生视图，`pulse-ring.structurizr.dsl` 与代码才是事实源。
