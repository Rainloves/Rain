export function randomBetween(min: number, max: number): number {
  if (!(max > min)) return min
  let roll = Math.random()
  if (typeof crypto !== 'undefined' && typeof crypto.getRandomValues === 'function') {
    const buf = new Uint32Array(1)
    crypto.getRandomValues(buf)
    roll = buf[0] / 4294967296
  }
  return min + roll * (max - min)
}
