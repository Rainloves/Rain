export type SoundId =
  | 'classic'
  | 'bell'
  | 'urgent'
  | 'soft'
  | 'trill'
  | 'chime'
  | 'pulse'
  | 'droplet'
  | 'marimba'
  | 'breeze'
  | 'flute'
  | 'chord'

export interface Tone {
  at: number
  dur: number
  f1: number
  f2?: number
  type: OscillatorType
}

export interface SoundPreset {
  id: SoundId
  name: string
  hint: string
  cycle: number
  level: number
  shape?: 'decay'
  tones: Tone[]
  bars: number[]
}

export const SOUNDS: SoundPreset[] = [
  {
    id: 'classic',
    name: '经典滴滴',
    hint: '标志性的双频提示',
    cycle: 1.2,
    level: 1,
    tones: [
      { at: 0, dur: 0.16, f1: 880, f2: 930, type: 'triangle' },
      { at: 0.28, dur: 0.16, f1: 880, f2: 930, type: 'triangle' },
    ],
    bars: [0.32, 0.72, 0.5, 0.9, 0.38, 0.62, 0.86, 0.44, 0.3, 0.68, 0.52, 0.82],
  },
  {
    id: 'bell',
    name: '双音门铃',
    hint: '温暖饱满的双音',
    cycle: 1.7,
    level: 0.95,
    shape: 'decay',
    tones: [
      { at: 0, dur: 0.36, f1: 988, f2: 988, type: 'sine' },
      { at: 0.4, dur: 0.72, f1: 784, f2: 784, type: 'sine' },
    ],
    bars: [0.2, 0.5, 0.86, 0.64, 0.34, 0.72, 0.96, 0.58, 0.26, 0.46, 0.8, 0.4],
  },
  {
    id: 'urgent',
    name: '急促三连',
    hint: '高频强提醒',
    cycle: 0.72,
    level: 0.5,
    tones: [
      { at: 0, dur: 0.09, f1: 1150, f2: 1150, type: 'square' },
      { at: 0.14, dur: 0.09, f1: 1150, f2: 1150, type: 'square' },
      { at: 0.28, dur: 0.09, f1: 1150, f2: 1150, type: 'square' },
    ],
    bars: [0.86, 0.32, 0.9, 0.36, 0.84, 0.3, 0.92, 0.34, 0.88, 0.3, 0.86, 0.36],
  },
  {
    id: 'soft',
    name: '轻柔双音',
    hint: '柔和上行，不刺耳',
    cycle: 1.9,
    level: 0.9,
    shape: 'decay',
    tones: [{ at: 0, dur: 0.58, f1: 523, f2: 659, type: 'sine' }],
    bars: [0.18, 0.34, 0.54, 0.76, 0.5, 0.3, 0.22, 0.4, 0.62, 0.44, 0.26, 0.18],
  },
  {
    id: 'trill',
    name: '轻快颤音',
    hint: '快速交替，灵动跳跃',
    cycle: 1.35,
    level: 0.42,
    tones: [
      { at: 0, dur: 0.11, f1: 1750, f2: 2350, type: 'sine' },
      { at: 0.17, dur: 0.11, f1: 2350, f2: 1750, type: 'sine' },
      { at: 0.34, dur: 0.11, f1: 1750, f2: 2350, type: 'sine' },
    ],
    bars: [0.4, 0.95, 0.36, 0.88, 0.42, 0.92, 0.34, 0.86, 0.4, 0.9, 0.36, 0.84],
  },
  {
    id: 'chime',
    name: '晶莹钟声',
    hint: '通透泛音，余韵悠长',
    cycle: 2.6,
    level: 0.42,
    shape: 'decay',
    tones: [
      { at: 0, dur: 1.5, f1: 1318.5, f2: 1318.5, type: 'sine' },
      { at: 0.05, dur: 1.05, f1: 1975.5, f2: 1975.5, type: 'sine' },
    ],
    bars: [0.24, 0.52, 0.8, 0.98, 0.7, 0.42, 0.28, 0.5, 0.74, 0.9, 0.56, 0.3],
  },
  {
    id: 'pulse',
    name: '电子脉冲',
    hint: '短促上行，科技感',
    cycle: 1.15,
    level: 0.28,
    tones: [
      { at: 0, dur: 0.18, f1: 440, f2: 880, type: 'sawtooth' },
      { at: 0.34, dur: 0.18, f1: 660, f2: 1320, type: 'sawtooth' },
    ],
    bars: [0.28, 0.55, 0.82, 0.45, 0.7, 0.36, 0.9, 0.5, 0.3, 0.66, 0.44, 0.78],
  },
  {
    id: 'droplet',
    name: '水滴清音',
    hint: '圆润下坠，通透',
    cycle: 1.55,
    level: 0.55,
    shape: 'decay',
    tones: [
      { at: 0, dur: 0.34, f1: 1320, f2: 660, type: 'sine' },
      { at: 0.42, dur: 0.5, f1: 990, f2: 520, type: 'sine' },
    ],
    bars: [0.18, 0.44, 0.86, 0.62, 0.3, 0.52, 0.92, 0.66, 0.26, 0.4, 0.74, 0.34],
  },
  {
    id: 'marimba',
    name: '木琴三音',
    hint: '木质三音，温暖',
    cycle: 2,
    level: 0.5,
    shape: 'decay',
    tones: [
      { at: 0, dur: 0.5, f1: 523.25, f2: 523.25, type: 'triangle' },
      { at: 0.2, dur: 0.55, f1: 659.25, f2: 659.25, type: 'triangle' },
      { at: 0.4, dur: 0.75, f1: 783.99, f2: 783.99, type: 'triangle' },
    ],
    bars: [0.2, 0.4, 0.62, 0.86, 0.68, 0.46, 0.26, 0.38, 0.58, 0.8, 0.52, 0.32],
  },
  {
    id: 'breeze',
    name: '风铃微风',
    hint: '空灵泛音，轻盈',
    cycle: 3.1,
    level: 0.3,
    shape: 'decay',
    tones: [
      { at: 0, dur: 1.4, f1: 1567.98, f2: 1567.98, type: 'sine' },
      { at: 0.22, dur: 1.2, f1: 2093, f2: 2093, type: 'sine' },
      { at: 0.5, dur: 1.5, f1: 1760, f2: 1760, type: 'sine' },
      { at: 0.86, dur: 1.1, f1: 2637.02, f2: 2637.02, type: 'sine' },
    ],
    bars: [0.16, 0.34, 0.56, 0.3, 0.7, 0.44, 0.22, 0.5, 0.78, 0.38, 0.6, 0.26],
  },
  {
    id: 'flute',
    name: '陶笛轻音',
    hint: '温润双音，低刺激',
    cycle: 2.4,
    level: 0.46,
    shape: 'decay',
    tones: [
      { at: 0, dur: 0.72, f1: 392, f2: 392, type: 'sine' },
      { at: 0.52, dur: 1.1, f1: 523.25, f2: 523.25, type: 'sine' },
    ],
    bars: [0.18, 0.36, 0.58, 0.8, 0.62, 0.4, 0.24, 0.34, 0.56, 0.74, 0.48, 0.28],
  },
  {
    id: 'chord',
    name: '氛围和弦',
    hint: '三音叠置，舒展',
    cycle: 3.4,
    level: 0.26,
    shape: 'decay',
    tones: [
      { at: 0, dur: 1.8, f1: 523.25, f2: 523.25, type: 'sine' },
      { at: 0.04, dur: 1.65, f1: 659.25, f2: 659.25, type: 'sine' },
      { at: 0.08, dur: 1.5, f1: 783.99, f2: 783.99, type: 'sine' },
    ],
    bars: [0.14, 0.3, 0.5, 0.72, 0.54, 0.34, 0.2, 0.4, 0.64, 0.84, 0.6, 0.36],
  },
]

export const SOUND_MAP: Record<SoundId, SoundPreset> = Object.fromEntries(
  SOUNDS.map((sound) => [sound.id, sound]),
) as Record<SoundId, SoundPreset>

export function soundName(id: SoundId): string {
  return SOUND_MAP[id]?.name ?? '自定义音效'
}
