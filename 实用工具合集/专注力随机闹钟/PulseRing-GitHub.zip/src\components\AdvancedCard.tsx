import { EyeOff, Music2, SlidersHorizontal, Timer, Volume1, Volume2, VolumeX } from 'lucide-react'
import type { BellEngine } from '../hooks/useBellEngine'
import { soundName } from '../lib/sounds'
import { Card, CardHead, SliderRow, Switch } from './primitives'

export function AdvancedCard({ engine }: { engine: BellEngine }) {
  const { settings, update, preview } = engine
  const VolumeIcon = settings.volume === 0 ? VolumeX : settings.volume < 0.5 ? Volume1 : Volume2

  return (
    <Card className="flex flex-1 flex-col p-6">
      <CardHead
        icon={<SlidersHorizontal size={16} />}
        title="节奏与音量"
        hint="调整后立即生效，不打断当前轮次"
        action={
          <button
            type="button"
            onClick={() => preview()}
            aria-label="试听当前提示音"
            className="grid h-9 w-9 place-items-center rounded-xl border border-white/[.08] bg-white/[.03] text-slate-400 transition hover:border-cyan-300/30 hover:text-cyan-200"
          >
            <Volume2 size={15} />
          </button>
        }
      />

      <div className="mt-6 space-y-5">
        <SliderRow
          icon={<Timer size={13} className="text-cyan-300/70" />}
          label="响铃时长"
          value={settings.ringSec}
          suffix=" 秒"
          min={3}
          max={60}
          step={1}
          onChange={(ringSec) => update({ ringSec })}
        />
        <SliderRow
          icon={<VolumeIcon size={13} className="text-indigo-300/80" />}
          label="音量"
          value={Math.round(settings.volume * 100)}
          suffix="%"
          min={0}
          max={100}
          step={1}
          onChange={(volume) => update({ volume: volume / 100 })}
        />
      </div>

      <div className="mt-6 flex items-start justify-between gap-4 rounded-2xl border border-white/[.06] bg-white/[.02] p-4">
        <div className="flex items-start gap-3">
          <div className="grid h-8 w-8 shrink-0 place-items-center rounded-lg border border-white/[.07] bg-white/[.04] text-slate-400">
            <EyeOff size={14} />
          </div>
          <div>
            <p className="text-[12px] font-medium text-slate-200">遮挡时间</p>
            <p className="mt-0.5 text-[10px] leading-4 text-slate-500">
              隐藏倒计时、预计响铃时刻与标签页秒数，保留状态提示
            </p>
          </div>
        </div>
        <Switch checked={settings.mask} onChange={(mask) => update({ mask })} label="遮挡时间" />
      </div>

      <div className="mt-auto flex items-center gap-2 pt-5 text-[10px] text-slate-600">
        <Music2 size={12} className="text-slate-500" />
        当前音色
        <span className="font-medium text-slate-400">{soundName(settings.soundId)}</span>
        <span className="h-1 w-1 rounded-full bg-slate-700" />
        每次 {settings.ringSec} 秒
      </div>
    </Card>
  )
}
