import clsx from 'clsx'
import { AudioLines, Check, Play, Volume2 } from 'lucide-react'
import type { BellEngine } from '../hooks/useBellEngine'
import { SOUNDS } from '../lib/sounds'
import { Card, CardHead } from './primitives'

export function SoundRack({ engine }: { engine: BellEngine }) {
  const { settings, update, preview, status } = engine

  return (
    <Card className="p-6">
      <CardHead
        icon={<AudioLines size={16} />}
        title="提示音"
        hint="全部由 Web Audio 实时合成 · 点击卡片切换"
        action={
          <button
            type="button"
            onClick={() => preview()}
            className="inline-flex h-9 items-center gap-1.5 rounded-xl border border-white/[.08] bg-white/[.03] px-3 text-[11px] text-slate-300 transition hover:border-cyan-300/30 hover:bg-cyan-300/[.06] hover:text-cyan-100"
          >
            <Volume2 size={13} />
            试听当前
          </button>
        }
      />

      <div role="radiogroup" aria-label="提示音" className="mt-5 grid grid-cols-2 gap-2.5 sm:grid-cols-3 xl:grid-cols-6">
        {SOUNDS.map((sound) => {
          const selected = settings.soundId === sound.id
          return (
            <div
              key={sound.id}
              role="radio"
              aria-checked={selected}
              tabIndex={0}
              onClick={() => update({ soundId: sound.id })}
              onKeyDown={(event) => {
                if (event.key === 'Enter' || event.key === ' ') {
                  event.preventDefault()
                  update({ soundId: sound.id })
                }
              }}
              className={clsx(
                'sound-tile group relative cursor-pointer overflow-hidden rounded-2xl border p-4 transition-all duration-300 outline-none focus-visible:ring-2 focus-visible:ring-cyan-300/50',
                selected
                  ? 'border-cyan-300/35 bg-cyan-300/[.06] shadow-[0_18px_45px_-30px_rgba(56,189,248,.9)]'
                  : 'border-white/[.06] bg-white/[.02] hover:border-white/[.14] hover:bg-white/[.04]',
              )}
            >
              {selected && (
                <span className="absolute right-3 top-3 grid h-5 w-5 place-items-center rounded-full bg-cyan-300 text-slate-950 shadow-[0_0_14px_rgba(103,232,249,.6)]">
                  <Check size={11} strokeWidth={3.2} />
                </span>
              )}

              <div className={clsx('flex h-8 items-end gap-[3px]', selected && status === 'ringing' && 'wave-live')}>
                {sound.bars.map((bar, index) => (
                  <span
                    key={index}
                    className="wave-bar w-[3px] rounded-full"
                    style={{
                      height: `${6 + bar * 22}px`,
                      background: selected
                        ? 'linear-gradient(180deg,#a5f3fc,#818cf8)'
                        : 'linear-gradient(180deg,rgba(148,163,184,.7),rgba(100,116,139,.3))',
                      animationDelay: `${index * 55}ms`,
                    }}
                  />
                ))}
              </div>

              <div className={clsx('mt-3 text-[13px] font-medium transition', selected ? 'text-cyan-100' : 'text-slate-300')}>
                {sound.name}
              </div>
              <p className="mt-0.5 truncate pr-8 text-[10px] text-slate-500">{sound.hint}</p>

              <button
                type="button"
                aria-label={`试听 ${sound.name}`}
                onClick={(event) => {
                  event.stopPropagation()
                  preview(sound.id)
                }}
                onKeyDown={(event) => event.stopPropagation()}
                className={clsx(
                  'absolute bottom-3 right-3 grid h-7 w-7 place-items-center rounded-lg border border-white/[.1] bg-white/[.05] text-slate-300 transition hover:bg-white/[.12] hover:text-white focus-visible:opacity-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300/50',
                  selected ? 'opacity-100' : 'opacity-0 group-hover:opacity-100',
                )}
              >
                <Play size={11} className="fill-current" />
              </button>
            </div>
          )
        })}
      </div>
    </Card>
  )
}
