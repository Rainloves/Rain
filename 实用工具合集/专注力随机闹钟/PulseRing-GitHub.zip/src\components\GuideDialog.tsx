import { AnimatePresence, motion } from 'motion/react'
import { AlertTriangle, BookOpen, Sparkles, X } from 'lucide-react'
import { useCallback, useEffect, useRef, useState } from 'react'
import {
  GUIDE_BACKGROUND,
  GUIDE_LEAD,
  GUIDE_SCENARIOS,
  GUIDE_STEPS,
  GUIDE_SUBTITLE,
  GUIDE_WARNING,
} from '../lib/guide'

function SectionTitle({ index, title }: { index: string; title: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-[10px] font-semibold tabular-nums tracking-[0.16em] text-cyan-300/60">{index}</span>
      <span className="h-px w-4 bg-white/[.12]" />
      <h3 className="text-[12px] font-semibold tracking-wide text-slate-200">{title}</h3>
    </div>
  )
}

export function GuideDialog() {
  const [open, setOpen] = useState(false)
  const triggerRef = useRef<HTMLButtonElement>(null)
  const closeRef = useRef<HTMLButtonElement>(null)

  const close = useCallback(() => {
    setOpen(false)
    triggerRef.current?.focus()
  }, [])

  useEffect(() => {
    if (open) closeRef.current?.focus()
  }, [open])

  useEffect(() => {
    if (!open) return
    const previousOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'

    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        event.preventDefault()
        close()
      }
    }
    window.addEventListener('keydown', onKeyDown)

    return () => {
      document.body.style.overflow = previousOverflow
      window.removeEventListener('keydown', onKeyDown)
    }
  }, [open, close])

  return (
    <>
      <motion.button
        ref={triggerRef}
        type="button"
        aria-label="打开使用说明"
        onClick={() => setOpen(true)}
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.55, duration: 0.5, ease: 'easeOut' }}
        className="group fixed bottom-5 right-5 z-40 inline-flex items-center gap-2 rounded-full border border-white/[.1] bg-[#0a101b]/85 p-2 text-[11px] font-medium text-slate-300 shadow-[0_20px_45px_-18px_rgba(0,0,0,.95)] backdrop-blur-xl transition hover:border-cyan-300/35 hover:text-cyan-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300/50 sm:bottom-6 sm:right-6 sm:pr-4"
      >
        <span className="grid h-8 w-8 place-items-center rounded-full bg-cyan-300/10 text-cyan-200 shadow-[inset_0_1px_0_rgba(255,255,255,.08)] transition group-hover:bg-cyan-300/15">
          <BookOpen size={14} />
        </span>
        <span className="hidden sm:inline">使用说明</span>
      </motion.button>

      <AnimatePresence>
        {open && (
          <motion.div
            className="fixed inset-0 z-50 flex items-end justify-center p-3 sm:items-center sm:p-6"
            data-block-shortcuts="true"
          >
            <motion.div
              className="absolute inset-0 bg-[#02040a]/75 backdrop-blur-md"
              onClick={close}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25 }}
            />

            <motion.div
              role="dialog"
              aria-modal="true"
              aria-labelledby="guide-title"
              className="glass relative flex max-h-[88vh] w-full max-w-2xl flex-col overflow-hidden"
              initial={{ opacity: 0, y: 26, scale: 0.985 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 18, scale: 0.985 }}
              transition={{ type: 'spring', stiffness: 280, damping: 28 }}
              onKeyDown={(event) => {
                if (event.key !== 'Tab') return
                const focusables = event.currentTarget.querySelectorAll<HTMLElement>(
                  'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])',
                )
                if (focusables.length === 0) return
                const first = focusables[0]
                const last = focusables[focusables.length - 1]
                if (event.shiftKey && document.activeElement === first) {
                  event.preventDefault()
                  last.focus()
                } else if (!event.shiftKey && document.activeElement === last) {
                  event.preventDefault()
                  first.focus()
                }
              }}
            >
              <div className="flex items-start justify-between gap-4 border-b border-white/[.06] px-6 pb-5 pt-6">
                <div className="flex items-start gap-3.5">
                  <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl border border-cyan-300/20 bg-cyan-300/[.08] text-cyan-200 shadow-[inset_0_1px_0_rgba(255,255,255,.08)]">
                    <BookOpen size={17} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h2 id="guide-title" className="text-[16px] font-semibold tracking-tight text-white">
                        使用说明
                      </h2>
                      <span className="rounded-md border border-white/[.08] bg-white/[.04] px-1.5 py-0.5 text-[9px] tracking-[0.14em] text-slate-500">
                        RESEARCH
                      </span>
                    </div>
                    <p className="mt-0.5 text-[11px] text-slate-500">{GUIDE_SUBTITLE}</p>
                  </div>
                </div>
                <button
                  ref={closeRef}
                  type="button"
                  onClick={close}
                  aria-label="关闭使用说明"
                  className="grid h-9 w-9 shrink-0 place-items-center rounded-xl border border-white/[.08] bg-white/[.03] text-slate-400 transition hover:border-white/15 hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-300/50"
                >
                  <X size={15} />
                </button>
              </div>

              <div className="min-h-0 flex-1 overflow-y-auto px-6 py-5">
                <div className="relative overflow-hidden rounded-2xl border border-cyan-300/15 bg-cyan-300/[.045] p-4">
                  <div className="absolute inset-y-0 left-0 w-px bg-gradient-to-b from-cyan-300/70 via-indigo-300/30 to-transparent" />
                  <p className="text-[12.5px] leading-6 text-slate-200">{GUIDE_LEAD}</p>
                </div>

                <section className="mt-6">
                  <SectionTitle index="01" title="研究背景" />
                  <div className="mt-3 space-y-3">
                    {GUIDE_BACKGROUND.map((paragraph) => (
                      <p key={paragraph.slice(0, 24)} className="text-[12px] leading-6 text-slate-400">
                        {paragraph}
                      </p>
                    ))}
                  </div>
                </section>

                <section className="mt-6">
                  <SectionTitle index="02" title="边界条件" />
                  <div className="mt-3 flex items-start gap-3 rounded-2xl border border-amber-300/15 bg-amber-300/[.045] p-4">
                    <AlertTriangle size={15} className="mt-0.5 shrink-0 text-amber-300/80" />
                    <p className="text-[12px] leading-6 text-amber-100/70">{GUIDE_WARNING}</p>
                  </div>
                </section>

                <section className="mt-6">
                  <SectionTitle index="03" title="如何使用" />
                  <ol className="mt-3 space-y-3">
                    {GUIDE_STEPS.map((step, index) => (
                      <li key={step.title} className="flex gap-3">
                        <span className="mt-0.5 grid h-6 w-6 shrink-0 place-items-center rounded-lg border border-white/[.07] bg-white/[.04] text-[10px] font-semibold tabular-nums text-cyan-200/80">
                          {String(index + 1).padStart(2, '0')}
                        </span>
                        <div>
                          <p className="text-[12px] font-medium text-slate-200">{step.title}</p>
                          <p className="mt-0.5 text-[11px] leading-5 text-slate-500">{step.detail}</p>
                        </div>
                      </li>
                    ))}
                  </ol>
                </section>

                <section className="mt-6">
                  <SectionTitle index="04" title="适用情境" />
                  <div className="mt-3 space-y-2">
                    {GUIDE_SCENARIOS.map((scenario) => (
                      <div
                        key={scenario.title}
                        className="flex items-start gap-3 rounded-xl border border-white/[.06] bg-white/[.02] px-3.5 py-3"
                      >
                        <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-cyan-300/80" />
                        <div>
                          <p className="text-[11px] font-medium text-slate-200">{scenario.title}</p>
                          <p className="mt-0.5 text-[10px] leading-5 text-slate-500">{scenario.detail}</p>
                        </div>
                      </div>
                    ))}
                    <div className="flex items-center gap-2 rounded-xl border border-dashed border-white/[.08] px-3.5 py-3 text-[10px] text-slate-600">
                      <Sparkles size={12} />
                      更多建议使用情形将陆续补充
                    </div>
                  </div>
                </section>
              </div>

              <div className="flex flex-col gap-1.5 border-t border-white/[.06] px-6 py-4 text-[10px] text-slate-600 sm:flex-row sm:items-center sm:justify-between">
                <span>内容整理自随机探针与心智游移相关研究</span>
                <span className="flex items-center gap-1.5">
                  <kbd className="kbd">Esc</kbd> 关闭
                </span>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
