import clsx from 'clsx'
import { Activity, Pause, Play, Square, Volume2, Waves } from 'lucide-react'
import type { BellEngine } from '../hooks/useBellEngine'
import { formatCountdown, formatInterval, formatTimeOfDay } from '../lib/format'

const RADIUS = 148
const CIRCUMFERENCE = 2 * Math.PI * RADIUS

export function Stage({ engine }: { engine: BellEngine }) {
  const { status, phase, settings, remainingMs, fraction, waitMs, nextAt, rings, preview } = engine
  const masked = settings.mask
  const hot = phase === 'ringing'
  const idle = status === 'idle'
  const paused = status === 'paused'
  const canStop = status !== 'idle'

  const digits = masked && !idle ? '••:••' : idle ? '00:00' : formatCountdown(remainingMs)

  const eyebrow = idle
    ? '尚未开始'
    : paused
      ? phase === 'ringing'
        ? '响铃中 · 已暂停'
        : '已暂停'
      : phase === 'ringing'
        ? '本次响铃剩余'
        : '距离下次响铃'

  const primaryLabel = idle ? '开始随机提醒' : paused ? '继续运行' : '暂停'
  const gradient = hot ? 'url(#hotGrad)' : 'url(#calmGrad)'

  return (
    <section className="glass flex h-full flex-col p-6 sm:p-7">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-[10px] font-medium uppercase tracking-[0.22em] text-slate-500">
          <Activity size={13} className="text-cyan-300/70" />
          实时仪表
        </div>
        <span className="text-[10px] tracking-wide text-slate-600">
          {masked ? '时间遮挡已开启' : '精确到秒 · 提前排程'}
        </span>
      </div>

      <div className="flex flex-1 flex-col items-center justify-center py-6">
        <div className="relative aspect-square w-full max-w-[352px]">
          <div className="pointer-events-none absolute inset-8 rounded-full bg-[radial-gradient(circle_at_50%_45%,rgba(56,189,248,.14),transparent_68%)] blur-2xl animate-breathe" />
          <div
            className={clsx(
              'pointer-events-none absolute inset-4 rounded-full bg-[radial-gradient(circle_at_50%_50%,rgba(251,191,36,.28),transparent_66%)] blur-3xl transition-opacity duration-700',
              status === 'ringing' ? 'animate-breathe opacity-100' : 'opacity-0',
            )}
          />

          <svg viewBox="0 0 340 340" className="relative h-full w-full -rotate-90" aria-hidden>
            <defs>
              <linearGradient id="calmGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#a5f3fc" />
                <stop offset="48%" stopColor="#22d3ee" />
                <stop offset="100%" stopColor="#818cf8" />
              </linearGradient>
              <linearGradient id="hotGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#fde68a" />
                <stop offset="52%" stopColor="#fb923c" />
                <stop offset="100%" stopColor="#f472b6" />
              </linearGradient>
            </defs>

            {Array.from({ length: 60 }, (_, index) => {
              const angle = (index / 60) * Math.PI * 2
              const major = index % 5 === 0
              const inner = 157
              const outer = major ? 164.5 : 161.5
              return (
                <line
                  key={index}
                  x1={170 + Math.cos(angle) * inner}
                  y1={170 + Math.sin(angle) * inner}
                  x2={170 + Math.cos(angle) * outer}
                  y2={170 + Math.sin(angle) * outer}
                  stroke="rgba(148,163,184,.22)"
                  strokeWidth={major ? 1.3 : 0.7}
                  strokeLinecap="round"
                />
              )
            })}

            <circle cx="170" cy="170" r="152" fill="none" stroke="rgba(255,255,255,.04)" strokeWidth="1" />
            <circle cx="170" cy="170" r={RADIUS} fill="none" stroke="rgba(255,255,255,.065)" strokeWidth="11" />
            <circle cx="170" cy="170" r={RADIUS - 20} fill="none" stroke="rgba(255,255,255,.035)" strokeWidth="1" />

            {masked && !idle ? (
              <circle
                className="ring-sweep"
                cx="170"
                cy="170"
                r={RADIUS}
                fill="none"
                stroke={gradient}
                strokeWidth="11"
                strokeLinecap="round"
                strokeDasharray={`${CIRCUMFERENCE * 0.14} ${CIRCUMFERENCE * 0.86}`}
                opacity=".85"
              />
            ) : (
              <>
                <circle
                  className="ring-progress"
                  cx="170"
                  cy="170"
                  r={RADIUS}
                  fill="none"
                  stroke={gradient}
                  strokeWidth="17"
                  strokeLinecap="round"
                  strokeDasharray={CIRCUMFERENCE}
                  strokeDashoffset={CIRCUMFERENCE * (1 - fraction)}
                  opacity={fraction > 0 ? 0.22 : 0}
                  style={{ filter: 'blur(9px)' }}
                />
                <circle
                  className="ring-progress"
                  cx="170"
                  cy="170"
                  r={RADIUS}
                  fill="none"
                  stroke={gradient}
                  strokeWidth="11"
                  strokeLinecap="round"
                  strokeDasharray={CIRCUMFERENCE}
                  strokeDashoffset={CIRCUMFERENCE * (1 - fraction)}
                  style={{ filter: 'drop-shadow(0 0 8px rgba(103,232,249,.22))' }}
                />
              </>
            )}
          </svg>

          <div className="absolute inset-0 flex flex-col items-center justify-center px-10 text-center">
            <div className="flex items-center gap-2 text-[10px] font-medium uppercase tracking-[0.24em] text-slate-500">
              <span
                className={clsx(
                  'h-1.5 w-1.5 rounded-full',
                  status === 'ringing'
                    ? 'bg-amber-300 shadow-[0_0_10px_rgba(252,211,77,.9)]'
                    : status === 'waiting'
                      ? 'bg-cyan-300 shadow-[0_0_10px_rgba(103,232,249,.9)]'
                      : paused
                        ? 'bg-violet-300'
                        : 'bg-slate-500',
                )}
              />
              {eyebrow}
            </div>

            <div
              className={clsx(
                'digits mt-2 text-[58px] font-semibold leading-none sm:text-[64px]',
                masked && !idle ? 'masked-sheen' : idle ? 'text-slate-500' : 'text-white',
                status === 'ringing' && 'drop-shadow-[0_0_26px_rgba(251,191,36,.35)]',
              )}
            >
              {digits}
            </div>

            <div className="mt-3 min-h-[34px] space-y-1">
              {masked && !idle ? (
                <p className="text-[10px] tracking-wide text-slate-500">时间已遮挡 · 保留状态提示</p>
              ) : idle ? (
                <p className="text-[10px] leading-4 tracking-wide text-slate-500">设定区间后开始，响铃时刻完全随机</p>
              ) : phase === 'ringing' ? (
                <>
                  <p className="text-[11px] text-slate-300">
                    第 {rings} 次响铃 · 持续 {settings.ringSec} 秒
                  </p>
                  <p className="text-[10px] text-slate-500">{paused ? '已暂停，继续后补完剩余时长' : '提示音正在播放'}</p>
                </>
              ) : (
                <>
                  <p className="text-[11px] text-slate-300">
                    本轮随机间隔 <span className="tabular-nums text-slate-100">{formatInterval(waitMs)}</span>
                  </p>
                  <p className="text-[10px] text-slate-500">
                    {nextAt !== null ? `预计 ${formatTimeOfDay(nextAt)} 响铃` : paused ? '继续后按原进度恢复' : '正在排程'}
                  </p>
                </>
              )}
            </div>
          </div>
        </div>

        <div className="mt-6 flex w-full flex-col gap-2.5 sm:flex-row">
          <button
            type="button"
            onClick={engine.toggle}
            className="group relative inline-flex h-12 flex-1 items-center justify-center gap-2 overflow-hidden rounded-2xl bg-gradient-to-r from-cyan-300 via-sky-300 to-indigo-300 px-6 text-[13px] font-semibold text-slate-950 shadow-[0_20px_45px_-22px_rgba(103,232,249,.9)] transition duration-300 hover:brightness-110 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-200/70 focus-visible:ring-offset-2 focus-visible:ring-offset-[#080b12] active:scale-[.99]"
          >
            {idle || paused ? <Play size={16} className="fill-slate-950" /> : <Pause size={16} className="fill-slate-950" />}
            {primaryLabel}
          </button>

          <button
            type="button"
            onClick={engine.stop}
            disabled={!canStop}
            className="inline-flex h-12 items-center justify-center gap-2 rounded-2xl border border-white/[.09] bg-white/[.03] px-5 text-[13px] font-medium text-slate-300 transition hover:border-white/15 hover:bg-white/[.06] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-200/50 disabled:cursor-not-allowed disabled:opacity-30"
          >
            <Square size={13} className="fill-current" />
            停止
          </button>

          <button
            type="button"
            onClick={() => preview()}
            className="inline-flex h-12 items-center justify-center gap-2 rounded-2xl border border-white/[.09] bg-white/[.03] px-5 text-[13px] font-medium text-slate-300 transition hover:border-white/15 hover:bg-white/[.06] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-cyan-200/50"
          >
            <Volume2 size={15} />
            试听
          </button>
        </div>
      </div>

      <div className="mt-5 flex flex-wrap items-center justify-center gap-x-4 gap-y-2 border-t border-white/[.05] pt-4 text-[10px] text-slate-600">
        <span className="flex items-center gap-1.5">
          <kbd className="kbd">Space</kbd> 开始 / 暂停
        </span>
        <span className="flex items-center gap-1.5">
          <kbd className="kbd">Esc</kbd> 停止
        </span>
        <span className="flex items-center gap-1.5">
          <kbd className="kbd">M</kbd> 遮挡时间
        </span>
        <span className="flex items-center gap-1.5">
          <Waves size={11} className="text-emerald-300/60" />
          音频提前排程，后台也准时
        </span>
      </div>
    </section>
  )
}
