import clsx from 'clsx'
import { ListTree, Trash2 } from 'lucide-react'
import type { BellEngine, LogKind } from '../hooks/useBellEngine'
import { formatLogTime } from '../lib/format'
import { Card, CardHead } from './primitives'

const KIND_DOT: Record<LogKind, string> = {
  start: 'bg-cyan-300 shadow-[0_0_8px_rgba(103,232,249,.7)]',
  ring: 'bg-amber-300 shadow-[0_0_8px_rgba(252,211,77,.7)]',
  pause: 'bg-violet-300',
  resume: 'bg-emerald-300',
  stop: 'bg-rose-300',
  info: 'bg-slate-400',
}

export function LogPanel({ engine }: { engine: BellEngine }) {
  const { logs, clearLogs, planCount } = engine

  return (
    <Card className="flex h-full min-h-[330px] flex-col p-6">
      <CardHead
        icon={<ListTree size={16} />}
        title="活动记录"
        hint={`${logs.length} 条记录 · 新的在最上方`}
        action={
          <button
            type="button"
            onClick={clearLogs}
            disabled={logs.length === 0}
            className="inline-flex h-8 items-center gap-1.5 rounded-lg border border-white/[.07] bg-white/[.03] px-2.5 text-[10px] text-slate-400 transition hover:border-rose-300/25 hover:text-rose-200 disabled:cursor-not-allowed disabled:opacity-30"
          >
            <Trash2 size={11} />
            清空
          </button>
        }
      />

      <div className="mt-4 max-h-[310px] flex-1 overflow-y-auto pr-1">
        {logs.length === 0 ? (
          <div className="flex h-full min-h-[190px] flex-col items-center justify-center gap-3 text-center">
            <div className="grid h-12 w-12 place-items-center rounded-2xl border border-white/[.06] bg-white/[.025] text-slate-600">
              <ListTree size={18} />
            </div>
            <div>
              <p className="text-[12px] text-slate-400">还没有记录</p>
              <p className="mt-1 text-[10px] text-slate-600">点击开始后，每次响铃都会记录在这里</p>
            </div>
          </div>
        ) : (
          <ul className="space-y-0.5">
            {logs.map((entry) => (
              <li
                key={entry.id}
                className="flex gap-3 rounded-xl px-2 py-2 transition-colors hover:bg-white/[.03]"
              >
                <span className={clsx('mt-[7px] h-1.5 w-1.5 shrink-0 rounded-full', KIND_DOT[entry.kind])} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-baseline justify-between gap-3">
                    <span className="truncate text-[12px] text-slate-200">{entry.title}</span>
                    <span className="shrink-0 text-[10px] tabular-nums text-slate-600">
                      {formatLogTime(entry.at)}
                    </span>
                  </div>
                  {entry.detail && (
                    <p className="mt-0.5 truncate text-[10px] leading-4 text-slate-500">{entry.detail}</p>
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>

      <div className="mt-4 flex items-center justify-between border-t border-white/[.05] pt-3 text-[10px] text-slate-600">
        <span className="flex items-center gap-1.5">
          <span className="h-1 w-1 rounded-full bg-emerald-300/80" />
          已排程 {planCount} 轮
        </span>
        <span>最多保留 80 条</span>
      </div>
    </Card>
  )
}
