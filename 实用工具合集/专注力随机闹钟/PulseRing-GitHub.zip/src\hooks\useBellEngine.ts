import { useCallback, useEffect, useRef, useState } from 'react'
import { BellAudio } from '../lib/audio'
import { formatCountdown, formatInterval } from '../lib/format'
import { randomBetween } from '../lib/random'
import { loadSettings, normalizeSettings, rangeMs, saveSettings, type Settings } from '../lib/settings'
import { SOUND_MAP, soundName, type SoundId } from '../lib/sounds'

export type Status = 'idle' | 'waiting' | 'ringing' | 'paused'
export type LogKind = 'start' | 'ring' | 'pause' | 'resume' | 'stop' | 'info'

export interface LogEntry {
  id: number
  at: number
  kind: LogKind
  title: string
  detail?: string
}

interface PlanEvent {
  waitStart: number
  start: number
  end: number
  wait: number
  ringMs: number
  logged: boolean
  nodes: OscillatorNode[]
}

interface PauseInfo {
  phase: 'waiting' | 'ringing'
  remain: number
  total: number
  fraction: number
  wait: number
  ringMs: number
}

interface EngineState {
  status: Status
  settings: Settings
  events: PlanEvent[]
  lastEnd: number | null
  pause: PauseInfo | null
  rings: number
  startedAt: number
  pausedAt: number
  pausedTotal: number
}

/** 提前排程 12 分钟，标签页在后台也能准时响 */
const LOOKAHEAD_MS = 12 * 60 * 1000
const MAX_PLANNED = 12
const TICK_MS = 200

export function useBellEngine() {
  const [settings, setSettings] = useState<Settings>(() => loadSettings())
  const [status, setStatus] = useState<Status>('idle')
  const [now, setNow] = useState(() => Date.now())
  const [rings, setRings] = useState(0)
  const [planCount, setPlanCount] = useState(0)
  const [logs, setLogs] = useState<LogEntry[]>([])

  const audioRef = useRef<BellAudio | null>(null)
  if (!audioRef.current) audioRef.current = new BellAudio()
  const audio = audioRef.current
  const logId = useRef(0)

  const H = useRef<EngineState>({
    status: 'idle',
    settings,
    events: [],
    lastEnd: null,
    pause: null,
    rings: 0,
    startedAt: 0,
    pausedAt: 0,
    pausedTotal: 0,
  })

  const pushLog = useCallback((kind: LogKind, title: string, detail?: string) => {
    setLogs((prev) => {
      const entry: LogEntry = { id: ++logId.current, at: Date.now(), kind, title, detail }
      return [entry, ...prev].slice(0, 80)
    })
  }, [])

  const planEvent = useCallback(
    (event: PlanEvent) => {
      const ctx = audio.ensure()
      if (!ctx) return
      const start = Date.now()
      const from = Math.max(start, event.start)
      const seconds = Math.max(0, (event.end - from) / 1000)
      const lead = Math.max(0, (event.start - start) / 1000)
      event.nodes = audio.schedule(ctx.currentTime + (lead > 0 ? lead : 0.02), seconds, SOUND_MAP[H.current.settings.soundId])
    },
    [audio],
  )

  const ensurePlan = useCallback(
    (at: number) => {
      const h = H.current
      if (h.status !== 'waiting' && h.status !== 'ringing') return
      let anchor = h.lastEnd
      if (anchor === null) anchor = at
      else if (anchor < at - 1500) anchor = at

      const { lo, hi } = rangeMs(h.settings)
      while (anchor < at + LOOKAHEAD_MS && h.events.length < MAX_PLANNED) {
        const wait = randomBetween(lo, hi)
        const ringMs = h.settings.ringSec * 1000
        const event: PlanEvent = {
          waitStart: anchor,
          start: anchor + wait,
          end: anchor + wait + ringMs,
          wait,
          ringMs,
          logged: false,
          nodes: [],
        }
        h.events.push(event)
        planEvent(event)
        anchor = event.end
        h.lastEnd = anchor
      }
    },
    [planEvent],
  )

  const replan = useCallback(
    (rearm: boolean) => {
      const h = H.current
      if (h.status !== 'waiting' && h.status !== 'ringing') return
      const head = h.events[0]
      if (!head) return
      for (const extra of h.events.slice(1)) audio.stop(extra.nodes)
      if (rearm) {
        audio.stop(head.nodes)
        head.nodes = []
        planEvent(head)
      }
      h.events = [head]
      h.lastEnd = head.end
      ensurePlan(Date.now())
      setPlanCount(h.events.length)
    },
    [audio, ensurePlan, planEvent],
  )

  const tick = useCallback(() => {
    const h = H.current
    if (h.status === 'idle' || h.status === 'paused') return
    const at = Date.now()

    while (h.events.length > 0 && at >= h.events[0].end) {
      const finished = h.events.shift()
      if (!finished) break
      h.lastEnd = finished.end
      if (!finished.logged) {
        finished.logged = true
        h.rings += 1
        pushLog(
          'ring',
          `第 ${h.rings} 次响铃`,
          `随机间隔 ${formatInterval(finished.wait)} · 持续 ${Math.round(finished.ringMs / 1000)} 秒`,
        )
      }
    }

    const head = h.events[0]
    if (head && at >= head.start) {
      if (h.status !== 'ringing') {
        h.status = 'ringing'
        setStatus('ringing')
      }
      if (!head.logged) {
        head.logged = true
        h.rings += 1
        pushLog('ring', `第 ${h.rings} 次响铃`, `随机间隔 ${formatInterval(head.wait)} · 持续 ${Math.round(head.ringMs / 1000)} 秒`)
      }
    } else if (h.status === 'ringing') {
      h.status = 'waiting'
      setStatus('waiting')
    }

    ensurePlan(at)
    setRings(h.rings)
    setPlanCount(h.events.length)
    setNow(at)
  }, [ensurePlan, pushLog])

  const start = useCallback(() => {
    const h = H.current
    audio.ensure()
    const at = Date.now()
    h.rings = 0
    h.events = []
    h.lastEnd = null
    h.pause = null
    h.startedAt = at
    h.pausedAt = 0
    h.pausedTotal = 0
    h.status = 'waiting'
    setStatus('waiting')
    setRings(0)
    setNow(at)

    const { lo, hi } = rangeMs(h.settings)
    pushLog(
      'start',
      '开始随机提醒',
      `区间 ${formatInterval(lo)} – ${formatInterval(hi)} · 每次 ${h.settings.ringSec} 秒 · ${soundName(h.settings.soundId)}`,
    )
    ensurePlan(at)
    setPlanCount(h.events.length)
  }, [audio, ensurePlan, pushLog])

  const pause = useCallback(() => {
    const h = H.current
    if (h.status !== 'waiting' && h.status !== 'ringing') return
    const at = Date.now()
    const head = h.events[0]
    if (!head) return

    const ringing = at >= head.start
    const total = ringing ? head.ringMs : head.wait
    const fraction = total > 0 ? Math.min(1, Math.max(0, (at - (ringing ? head.start : head.waitStart)) / total)) : 0

    h.pause = {
      phase: ringing ? 'ringing' : 'waiting',
      remain: Math.max(0, (ringing ? head.end : head.start) - at),
      total,
      fraction,
      wait: head.wait,
      ringMs: head.ringMs,
    }
    h.pausedAt = at
    h.status = 'paused'
    for (const event of h.events) audio.stop(event.nodes)
    h.events = []
    h.lastEnd = null
    setStatus('paused')
    setPlanCount(0)
    setNow(at)
    pushLog('pause', '已暂停', ringing ? '响铃阶段暂停，继续后会补完剩余时长' : '本轮随机结果已保留')
  }, [audio, pushLog])

  const resume = useCallback(() => {
    const h = H.current
    const paused = h.pause
    if (h.status !== 'paused' || !paused) return
    audio.ensure()
    const at = Date.now()

    let event: PlanEvent
    if (paused.phase === 'waiting') {
      event = {
        waitStart: at - (paused.wait - paused.remain),
        start: at + paused.remain,
        end: at + paused.remain + paused.ringMs,
        wait: paused.wait,
        ringMs: paused.ringMs,
        logged: false,
        nodes: [],
      }
    } else {
      const ringStart = at - (paused.ringMs - paused.remain)
      event = {
        waitStart: ringStart - paused.wait,
        start: ringStart,
        end: at + paused.remain,
        wait: paused.wait,
        ringMs: paused.ringMs,
        logged: true,
        nodes: [],
      }
    }

    h.events = [event]
    h.lastEnd = event.end
    h.pause = null
    h.pausedTotal += at - h.pausedAt
    h.pausedAt = 0
    h.status = paused.phase === 'ringing' ? 'ringing' : 'waiting'
    planEvent(event)
    ensurePlan(at)
    setStatus(h.status)
    setNow(at)
    setPlanCount(h.events.length)
    pushLog('resume', '继续运行', `保留剩余 ${formatInterval(Math.max(0, (paused.phase === 'ringing' ? event.end : event.start) - at))}`)
  }, [audio, ensurePlan, planEvent, pushLog])

  const stop = useCallback(() => {
    const h = H.current
    if (h.status === 'idle') return
    for (const event of h.events) audio.stop(event.nodes)
    audio.stopAll()
    h.events = []
    h.lastEnd = null
    h.pause = null
    h.status = 'idle'
    const totalRings = h.rings
    h.startedAt = 0
    h.pausedAt = 0
    h.pausedTotal = 0
    setStatus('idle')
    setPlanCount(0)
    setNow(Date.now())
    pushLog('stop', '已停止', `本次共响铃 ${totalRings} 次`)
  }, [audio, pushLog])

  const toggle = useCallback(() => {
    const state = H.current.status
    if (state === 'idle') start()
    else if (state === 'paused') resume()
    else pause()
  }, [pause, resume, start])

  const update = useCallback((patch: Partial<Settings>) => {
    setSettings((prev) => normalizeSettings({ ...prev, ...patch }))
  }, [])

  const preview = useCallback(
    (id?: SoundId) => {
      const sound = SOUND_MAP[id ?? H.current.settings.soundId]
      if (sound) audio.preview(sound)
    },
    [audio],
  )

  const clearLogs = useCallback(() => setLogs([]), [])

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (document.querySelector('[data-block-shortcuts="true"]')) return
      const target = event.target instanceof HTMLElement ? event.target : null
      const typing =
        !!target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.tagName === 'SELECT' ||
          target.isContentEditable)
      if (typing) return

      if (event.code === 'Space') {
        if (target && (target.tagName === 'BUTTON' || target.tagName === 'A' || target.closest('[role="radio"]'))) {
          return
        }
        event.preventDefault()
        toggle()
      } else if (event.key === 'Escape') {
        stop()
      } else if (event.key === 'm' || event.key === 'M') {
        update({ mask: !H.current.settings.mask })
      }
    }

    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [toggle, stop, update])


  const prevSettings = useRef(settings)
  useEffect(() => {
    const prev = prevSettings.current
    prevSettings.current = settings
    H.current.settings = settings
    saveSettings(settings)
    audio.setVolume(settings.volume)

    if (prev.soundId !== settings.soundId) {
      if (H.current.status !== 'idle') pushLog('info', '切换提示音', soundName(settings.soundId))
      replan(true)
    } else if (prev.loMin !== settings.loMin || prev.hiMin !== settings.hiMin || prev.ringSec !== settings.ringSec) {
      replan(false)
    }
  }, [settings, audio, pushLog, replan])

  useEffect(() => {
    const id = window.setInterval(tick, TICK_MS)
    return () => window.clearInterval(id)
  }, [tick])

  useEffect(() => {
    const onVisibility = () => {
      if (document.visibilityState === 'visible') tick()
    }
    document.addEventListener('visibilitychange', onVisibility)
    return () => document.removeEventListener('visibilitychange', onVisibility)
  }, [tick])

  useEffect(() => {
    const head = H.current.events[0]
    if (status === 'waiting' && head) {
      document.title = settings.mask ? '随机响铃提醒器' : `${formatCountdown(head.start - now)} · 随机响铃提醒器`
    } else if (status === 'ringing') {
      document.title = settings.mask ? '随机响铃提醒器' : '正在响铃 · 随机响铃提醒器'
    } else if (status === 'paused') {
      document.title = '已暂停 · 随机响铃提醒器'
    } else {
      document.title = 'PulseRing · 随机响铃提醒器'
    }
  }, [status, now, settings.mask])

  useEffect(() => {
    return () => {
      audio.stopAll()
    }
  }, [audio])

  const h = H.current
  const head = h.events[0]
  let remainingMs = 0
  let totalMs = 0
  let fraction = 0
  let waitMs = 0
  let nextAt: number | null = null

  if (status === 'waiting' && head) {
    remainingMs = Math.max(0, head.start - now)
    totalMs = head.wait
    fraction = totalMs > 0 ? Math.min(1, Math.max(0, (now - head.waitStart) / totalMs)) : 0
    waitMs = head.wait
    nextAt = head.start
  } else if (status === 'ringing' && head) {
    remainingMs = Math.max(0, head.end - now)
    totalMs = head.ringMs
    fraction = totalMs > 0 ? Math.min(1, Math.max(0, (now - head.start) / totalMs)) : 0
    waitMs = head.wait
  } else if (status === 'paused' && h.pause) {
    remainingMs = h.pause.remain
    totalMs = h.pause.total
    fraction = h.pause.fraction
    waitMs = h.pause.wait
  }

  const phase: 'idle' | 'waiting' | 'ringing' | 'paused' =
    status === 'paused' ? (h.pause?.phase ?? 'waiting') : status

  const uptimeMs =
    h.startedAt === 0 ? 0 : (status === 'paused' ? h.pausedAt : now) - h.startedAt - h.pausedTotal

  return {
    settings,
    update,
    status,
    phase,
    remainingMs,
    totalMs,
    fraction,
    waitMs,
    nextAt,
    rings,
    uptimeMs,
    planCount,
    logs,
    clearLogs,
    start,
    pause,
    resume,
    stop,
    toggle,
    preview,
  }
}

export type BellEngine = ReturnType<typeof useBellEngine>
