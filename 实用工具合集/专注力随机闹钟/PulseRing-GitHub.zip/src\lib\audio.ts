import type { SoundPreset } from './sounds'

type AudioContextCtor = typeof AudioContext

/**
 * 所有滴滴声都提前排在 AudioContext 的时间轴上，
 * 因此标签页切到后台、定时器被节流时依然会准时响。
 */
export class BellAudio {
  private ctx: AudioContext | null = null
  private master: GainNode | null = null
  private level = 0.65
  private live = new Set<OscillatorNode>()

  private gainValue(): number {
    return Math.pow(this.level, 1.5) * 0.7
  }

  ensure(): AudioContext | null {
    if (this.ctx) {
      if (this.ctx.state === 'suspended') void this.ctx.resume()
      return this.ctx
    }
    if (typeof window === 'undefined') return null
    const Ctor: AudioContextCtor | undefined =
      window.AudioContext ??
      (window as unknown as { webkitAudioContext?: AudioContextCtor }).webkitAudioContext
    if (!Ctor) return null

    const ctx = new Ctor()
    const master = ctx.createGain()
    master.gain.value = this.gainValue()
    master.connect(ctx.destination)
    this.ctx = ctx
    this.master = master
    return ctx
  }

  setVolume(value: number): void {
    this.level = Math.min(1, Math.max(0, value))
    if (!this.ctx || !this.master) return
    const now = this.ctx.currentTime
    this.master.gain.cancelScheduledValues(now)
    this.master.gain.setTargetAtTime(this.gainValue(), now, 0.04)
  }

  schedule(startAt: number, seconds: number, sound: SoundPreset): OscillatorNode[] {
    const ctx = this.ensure()
    if (!ctx || !this.master || seconds <= 0.03) return []

    const nodes: OscillatorNode[] = []
    const end = startAt + seconds
    const decay = sound.shape === 'decay'

    for (let base = startAt; base < end - 0.03; base += sound.cycle) {
      for (const tone of sound.tones) {
        const at = base + tone.at
        const dur = Math.min(tone.dur, end - at)
        if (dur < 0.04) continue

        const osc = ctx.createOscillator()
        const gain = ctx.createGain()
        osc.type = tone.type
        osc.frequency.setValueAtTime(tone.f1, at)
        if (tone.f2 !== undefined && tone.f2 !== tone.f1) {
          osc.frequency.exponentialRampToValueAtTime(tone.f2, at + dur)
        }

        gain.gain.setValueAtTime(0, at)
        gain.gain.linearRampToValueAtTime(sound.level, at + Math.min(0.014, dur * 0.25))
        if (decay) {
          gain.gain.exponentialRampToValueAtTime(0.0008, at + dur)
        } else {
          gain.gain.setValueAtTime(sound.level, at + Math.max(0.014, dur - Math.min(0.06, dur * 0.4)))
          gain.gain.linearRampToValueAtTime(0, at + dur)
        }

        osc.connect(gain)
        gain.connect(this.master)
        osc.onended = () => {
          this.live.delete(osc)
          osc.disconnect()
          gain.disconnect()
        }
        osc.start(at)
        osc.stop(at + dur + 0.03)

        this.live.add(osc)
        nodes.push(osc)
      }
    }
    return nodes
  }

  stop(nodes: OscillatorNode[]): void {
    const now = this.ctx?.currentTime
    for (const osc of nodes) {
      try {
        osc.stop(now)
      } catch {
        /* 已经停止的节点无需处理 */
      }
      this.live.delete(osc)
    }
  }

  stopAll(): void {
    this.stop([...this.live])
  }

  preview(sound: SoundPreset): void {
    const ctx = this.ensure()
    if (!ctx) return
    const duration = Math.min(2.8, sound.cycle * Math.max(1, sound.tones.length) + 0.4)
    this.schedule(ctx.currentTime + 0.02, duration, sound)
  }
}
