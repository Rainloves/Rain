import { useEffect, useState } from 'react'
import clsx from 'clsx'
import { Clock, Minus, Plus, Sparkles } from 'lucide-react'
import type { BellEngine } from '../hooks/useBellEngine'
import { clamp, formatInterval } from '../lib/format'
import { MAX_MINUTES, MIN_MINUTES } from '../lib/settings'
import { Card, CardHead } from './primitives'

const PRESETS = [
  { label: '1–3', lo: 1, hi: 3 },
  { label: '3–5', lo: 3, hi: 5 },
  { label: '5–10', lo: 5, hi: 10 },
  { label: '10–20', lo: 10, hi: 20 },
]

function draftOf(value: number): string {
  return Number.isInteger(value) ? String(value) : String(Number(value.toFixed(2)))
}

function MinuteField({
  label,
  value,
  onChange,
}: {
  label: string
  value: number
  onChange: (value: number) => void
}) {
  const [draft, setDraft] = useState(() => draftOf(value))

  useEffect(() => {
    setDraft(draftOf(value))
  }, [value])

  const commit = (raw: string) => {
    const parsed = Number(raw)
    if (raw.trim() !== '' && Number.isFinite(parsed) && parsed >= MIN_MINUTES) {
      onChange(clamp(parsed, MIN_MINUTES, MAX_MINUTES))
    } else {
      setDraft(draftOf(value))
    }
  }

  const step = (delta: number) => {
    onChange(clamp(Math.round((value + delta) * 10) / 10, MIN_MINUTES, MAX_MINUTES))
  }

  return (
    <div className="number-field glass-inset p-3 transition focus-within:border-cyan-300/35 focus-within:bg-cyan-300/[.03]">
      <div className="flex items-center justify-between">
        <span className="text-[10px] uppercase tracking-[0.18em] text-slate-500">{label}</span>
        <div className="flex items-center gap-1">
          <button
            type="button"
            aria-label={`${label} 减少`}
            onClick={() => step(-0.5)}
            className="grid h-5 w-5 place-items-center rounded-md border border-white/[.08] bg-white/[.04] text-slate-400 transition hover:bg-white/[.08] hover:text-white"
          >
            <Minus size={10} />
          </button>
          <button
            type="button"
            aria-label={`${label} 增加`}
            onClick={() => step(0.5)}
            className="grid h-5 w-5 place-items-center rounded-md border border-white/[.08] bg-white/[.04] text-slate-400 transition hover:bg-white/[.08] hover:text-white"
          >
            <Plus size={10} />
          </button>
        </div>
      </div>
      <div className="mt-1.5 flex items-baseline gap-1.5">
        <input
          type="number"
          aria-label={`${label}（分钟）`}
          inputMode="decimal"
          min={MIN_MINUTES}
          max={MAX_MINUTES}
          step={0.5}
          value={draft}
          onChange={(event) => {
            const raw = event.target.value
            setDraft(raw)
            const parsed = Number(raw)
            if (raw.trim() !== '' && Number.isFinite(parsed) && parsed >= MIN_MINUTES) {
              onChange(clamp(parsed, MIN_MINUTES, MAX_MINUTES))
            }
          }}
          onBlur={() => commit(draft)}
          onKeyDown={(event) => {
            if (event.key === 'Enter') {
              commit(draft)
              event.currentTarget.blur()
            }
          }}
          className="w-full min-w-0 bg-transparent text-[26px] font-semibold tabular-nums tracking-tight text-white outline-none"
        />
        <span className="shrink-0 text-[11px] text-slate-500">分钟</span>
      </div>
    </div>
  )
}

export function RangeCard({ engine }: { engine: BellEngine }) {
  const { settings, update } = engine
  const lo = Math.min(settings.loMin, settings.hiMin)
  const hi = Math.max(settings.loMin, settings.hiMin)
  const domain = Math.max(hi * 1.15, 1)
  const startPct = clamp((lo / domain) * 100, 0, 100)
  const endPct = clamp((hi / domain) * 100, 0, 100)
  const average = (lo + hi) / 2
  const activePreset = PRESETS.find(
    (preset) => Math.abs(preset.lo - settings.loMin) < 1e-6 && Math.abs(preset.hi - settings.hiMin) < 1e-6,
  )

  return (
    <Card className="p-6">
      <CardHead icon={<Clock size={16} />} title="随机区间" hint="每轮重新独立抽取等待时间" />

      <div className="mt-5 grid grid-cols-2 gap-3">
        <MinuteField label="最短等待" value={settings.loMin} onChange={(loMin) => update({ loMin })} />
        <MinuteField label="最长等待" value={settings.hiMin} onChange={(hiMin) => update({ hiMin })} />
      </div>

      <div className="mt-5">
        <div className="relative h-2.5 rounded-full bg-white/[.055]">
          <div
            className="absolute inset-y-0 rounded-full bg-gradient-to-r from-cyan-300/80 via-sky-400/80 to-indigo-400/80 shadow-[0_0_18px_rgba(56,189,248,.35)]"
            style={{ left: `${startPct}%`, right: `${100 - endPct}%` }}
          />
          <span
            className="absolute top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full border border-white/70 bg-[#081018] shadow-[0_0_0_3px_rgba(8,16,24,.9)]"
            style={{ left: `${startPct}%` }}
          />
          <span
            className="absolute top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full border border-white/70 bg-[#081018] shadow-[0_0_0_3px_rgba(8,16,24,.9)]"
            style={{ left: `${endPct}%` }}
          />
          <span
            className="absolute top-1/2 h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white shadow-[0_0_12px_rgba(255,255,255,.9)] animate-pulse"
            style={{ left: `${(startPct + endPct) / 2}%` }}
          />
        </div>
        <div className="mt-2 flex items-center justify-between text-[10px] text-slate-600">
          <span>随机区间</span>
          <span className="tabular-nums text-slate-500">
            {formatInterval(lo * 60_000)} – {formatInterval(hi * 60_000)}
          </span>
        </div>
      </div>

      <div className="mt-3 flex items-center gap-2 rounded-xl border border-white/[.05] bg-white/[.02] px-3 py-2 text-[10px] text-slate-500">
        <Sparkles size={12} className="shrink-0 text-cyan-300/60" />
        <span>
          平均每 <span className="font-medium text-slate-300">{formatInterval(average * 60_000)}</span> 响铃一次 · 顺序不限
        </span>
      </div>

      <div className="mt-4 flex flex-wrap gap-1.5">
        {PRESETS.map((preset) => {
          const active = activePreset === preset
          return (
            <button
              key={preset.label}
              type="button"
              onClick={() => update({ loMin: preset.lo, hiMin: preset.hi })}
              className={clsx(
                'rounded-lg border px-2.5 py-1.5 text-[11px] tabular-nums transition',
                active
                  ? 'border-cyan-300/35 bg-cyan-300/[.09] text-cyan-200'
                  : 'border-white/[.07] bg-white/[.03] text-slate-400 hover:border-white/15 hover:text-slate-200',
              )}
            >
              {preset.label} 分
            </button>
          )
        })}
      </div>
    </Card>
  )
}
