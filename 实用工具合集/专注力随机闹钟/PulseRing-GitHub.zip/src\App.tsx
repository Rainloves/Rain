import { motion } from 'motion/react'
import { Heart } from 'lucide-react'
import { AdvancedCard } from './components/AdvancedCard'
import { Backdrop } from './components/Backdrop'
import { BootScreen } from './components/BootScreen'
import { ContactDialog } from './components/ContactDialog'
import { GuideDialog } from './components/GuideDialog'
import { Header } from './components/Header'
import { LogPanel } from './components/LogPanel'
import { RangeCard } from './components/RangeCard'
import { SoundRack } from './components/SoundRack'
import { Stage } from './components/Stage'
import { Stats } from './components/Stats'
import { TipsCard } from './components/TipsCard'
import { useBellEngine } from './hooks/useBellEngine'

const rise = {
  initial: { opacity: 0, y: 14 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.55, ease: 'easeOut' as const },
}

export default function App() {
  const engine = useBellEngine()

  return (
    <div className="relative min-h-screen overflow-x-hidden">
      <Backdrop />
      <BootScreen />

      <div className="relative mx-auto w-full max-w-[1320px] px-5 pb-24 pt-7 sm:px-8 lg:px-10">
        <motion.div {...rise}>
          <Header engine={engine} />
        </motion.div>

        <main className="mt-7 space-y-5">
          <div className="grid gap-5 lg:grid-cols-12">
            <motion.div className="lg:col-span-7" {...rise} transition={{ ...rise.transition, delay: 0.05 }}>
              <Stage engine={engine} />
            </motion.div>

            <div className="flex flex-col gap-5 lg:col-span-5">
              <motion.div {...rise} transition={{ ...rise.transition, delay: 0.1 }}>
                <RangeCard engine={engine} />
              </motion.div>
              <motion.div className="flex flex-1 flex-col" {...rise} transition={{ ...rise.transition, delay: 0.15 }}>
                <AdvancedCard engine={engine} />
              </motion.div>
            </div>
          </div>

          <motion.div {...rise} transition={{ ...rise.transition, delay: 0.2 }}>
            <SoundRack engine={engine} />
          </motion.div>

          <motion.div {...rise} transition={{ ...rise.transition, delay: 0.25 }}>
            <Stats engine={engine} />
          </motion.div>

          <div className="grid gap-5 lg:grid-cols-12">
            <motion.div className="lg:col-span-7 xl:col-span-8" {...rise} transition={{ ...rise.transition, delay: 0.3 }}>
              <LogPanel engine={engine} />
            </motion.div>
            <motion.div className="lg:col-span-5 xl:col-span-4" {...rise} transition={{ ...rise.transition, delay: 0.35 }}>
              <TipsCard engine={engine} />
            </motion.div>
          </div>
        </main>

        <footer className="mt-8 flex flex-col items-center justify-between gap-3 border-t border-white/[.05] pt-5 text-[10px] text-slate-600 sm:flex-row">
          <span className="flex flex-wrap items-center justify-center gap-x-2 gap-y-1 sm:justify-start">
            <span>PulseRing · 随机响铃提醒器</span>
            <span className="h-0.5 w-0.5 rounded-full bg-slate-700" />
            <span className="inline-flex items-center gap-1.5">
              <Heart size={9} className="text-rose-300/60" />
              由 <span className="font-medium text-slate-400">Rainlove</span> 制作 · 免费开源
            </span>
          </span>
          <span className="flex flex-wrap items-center justify-center gap-x-2.5 gap-y-1">
            <span>React 19</span>
            <span className="h-0.5 w-0.5 rounded-full bg-slate-700" />
            <span>TypeScript</span>
            <span className="h-0.5 w-0.5 rounded-full bg-slate-700" />
            <span>Tailwind CSS v4</span>
            <span className="h-0.5 w-0.5 rounded-full bg-slate-700" />
            <span>Web Audio API</span>
          </span>
        </footer>
      </div>

      <GuideDialog />
      <ContactDialog />
    </div>
  )
}
